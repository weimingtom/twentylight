#ifndef NICO_ERRORBOX_INC
#define NICO_ERRORBOX_INC NICO_ERRORBOX_INC

//simple error box with ok button
void ErrorBox(const char* msg);

#endif //NICO_ERRORBOX_INC
