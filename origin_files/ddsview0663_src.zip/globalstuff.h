#ifndef DDSVIEW_GLOBALSTUFF
#define DDSVIEW_GLOBALSTUFF DDSVIEW_GLOBALSTUFF

typedef char EXT[6]; //TODO: are 5 chars per extension sufficient?

#define DDSVIEW_WIN32
//#define DDSVIEW_LINUX
//#define DDSVIEW_GTK

#define DDSVIEW_DRAW_GDI
//#define DDSVIEW_DRAW_OPENGL
//#define DDSVIEW_DRAW_GDK

#endif //DDSVIEW_GLOBALSTUFF
