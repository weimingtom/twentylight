#if !defined(AFX_IMAGEWNDDLG_H__DD7D36E6_471D_11D4_8F37_0000E8778115__INCLUDED_)
#define AFX_IMAGEWNDDLG_H__DD7D36E6_471D_11D4_8F37_0000E8778115__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ImageWndDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CImageWndDlg dialog

class CImageWndDlg : public CPropertyPage
{
	DECLARE_DYNCREATE(CImageWndDlg)

// Construction
public:
	COLORREF m_clrBkground;
	float m_fZoom;
	CImageWndDlg();
	~CImageWndDlg();

// Dialog Data
	//{{AFX_DATA(CImageWndDlg)
	enum { IDD = IDD_IMAGEWND };
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CImageWndDlg)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CImageWndDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelectBkcolor();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMAGEWNDDLG_H__DD7D36E6_471D_11D4_8F37_0000E8778115__INCLUDED_)
