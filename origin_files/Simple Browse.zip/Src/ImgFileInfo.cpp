// ImgFileInfo.cpp : implementation file
//

#include "stdafx.h"
#include "ImgFileInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CImgFileInfo


CImgFileInfo::CImgFileInfo(LPCTSTR lpszFileName) : CSHFileInfo(lpszFileName)
{
}

CImgFileInfo::~CImgFileInfo()
{
}

/////////////////////////////////////////////////////////////////////////////
// CImgFileInfo message handlers

BOOL CImgFileInfo::IsImageFile(CString strFileName, CString strFilter)
{
	BOOL bRes = FALSE;

	TCHAR drive[_MAX_DRIVE];
	TCHAR dir[_MAX_DIR];
	TCHAR fname[_MAX_FNAME];
	TCHAR ext[_MAX_EXT];
	LPTSTR p = NULL;

	_tsplitpath(strFileName.GetBuffer(_MAX_PATH), drive, dir, fname, ext);
	strFileName.ReleaseBuffer();
	p = ext;
	// From ".jpg" to "jpg"
	if (p != NULL && *p == '.')
		p += 1;

	// In filters string, filter seperate by ";", for example "gif;jpg;png"
	TCHAR szSeps[] = _T(";");
	LPTSTR lpszFilter, lpszFilters;
	lpszFilters = strFilter.GetBuffer(strFilter.GetLength());
	lpszFilter = _tcstok(lpszFilters, szSeps);
	while (lpszFilter != NULL)
	{
		if (_tcsicmp(lpszFilter, p) == 0 || *lpszFilter == '*')
		{
			bRes = TRUE;
			break;
		}
		lpszFilter = _tcstok(NULL, szSeps);
	}
	strFilter.ReleaseBuffer();
	
	return bRes;	
}

BOOL CImgFileInfo::IsImageFile(CString strFilter)
{
	return IsImageFile(m_strFileName, strFilter);
}

