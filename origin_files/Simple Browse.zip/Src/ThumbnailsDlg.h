#if !defined(AFX_THUMBNAILSDLG_H__3EF96213_4583_11D4_8F32_0000E8778115__INCLUDED_)
#define AFX_THUMBNAILSDLG_H__3EF96213_4583_11D4_8F32_0000E8778115__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ThumbnailsDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CThumbnailsDlg dialog

class CThumbnailsDlg : public CPropertyPage
{
	DECLARE_DYNCREATE(CThumbnailsDlg)

// Construction
public:
	CThumbnailsDlg();
	~CThumbnailsDlg();

// Dialog Data
	//{{AFX_DATA(CThumbnailsDlg)
	enum { IDD = IDD_THUMBNAILS };
	int		m_nChangeThumbSize;
	int		m_nThumbSize;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CThumbnailsDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CThumbnailsDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeThumbSize();
	afx_msg void OnSaveThumbFile();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_THUMBNAILSDLG_H__3EF96213_4583_11D4_8F32_0000E8778115__INCLUDED_)
