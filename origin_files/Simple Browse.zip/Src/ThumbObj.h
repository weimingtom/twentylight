#if !defined(AFX_THUMBOBJ_H__FBB65042_FF45_11D0_97CA_444553540000__INCLUDED_)
#define AFX_THUMBOBJ_H__FBB65042_FF45_11D0_97CA_444553540000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// ThumbObj.h : header file

#include "oxdib.h"
#include "ImgCon20.h"
#pragma comment(lib, "convert20.lib")

/////////////////////////////////////////////////////////////////////////////
// CThumbObj command target

/** *************************************************************************
** @Description: 
**	%This% class
**  is used as the image resource object.
**  
**  
** @Usage:
** @Creator:   Michael Zhang
** @Date:     99/07/20
** @Version:  1.0
************************************************************************** */
class CThumbObj : public CObject
{
	DECLARE_SERIAL(CThumbObj)
// Attributes
public:
	CThumbObj(LPCTSTR pszUNC = NULL);
	virtual ~CThumbObj();

	virtual void Serialize(CArchive& ar);
// Operations
public:	
	CString GetFullName() { return m_strFullName; }
	CString GetFileName() { return m_strFileName; }

	//create and paint
	virtual BOOL CreateThumbnail();
	void PaintThumbnail(CDC* pDC, CRect rectPos);
	
//	float RectFitToRect(CRect rectDest, CRect rectSrc, CRect & rectFit);
	
	//information
	BITMAPINFOHEADER* GetOrgImgInfoHeader();

	// Interface to access DIB object
	COXDIB* GetDIBObject();
	LPBYTE GetDIBPtr();
	BITMAPINFO* GetImgInfo();
	LPVOID GetImgBits();
	BOOL SaveImgAsFile(LPTSTR pszPath);
	WORD GetNumBitsPerPixel();
	WORD GetNumColors();
	CSize GetImgSize();
	BOOL IsImgEmpty();
	LPBYTE ImgMakeCopy();

	// have try to create thumbnail?
	BOOL HaveTryToCreateThumb();
	void SetHaveTryToCreateThumbFlag(BOOL bFlag = true);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CThumbObj)
	//}}AFX_VIRTUAL

// Implementation
protected:
	// name and size
	CString m_strFullName;
	CString m_strFileName;
	CSize m_sizeThumbSize;
	//image data
	COXDIB *m_pDIB;
	BITMAPINFOHEADER m_sOrgInfoHeader;	//original bitmap information

	// have try to create thumbnail?
	BOOL m_bHaveTryToCreateThumb;
};

//list type
typedef CTypedPtrList<CObList, CThumbObj*> CThumbObjList;

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_THUMBOBJ_H__FBB65042_FF45_11D0_97CA_444553540000__INCLUDED_)
