// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "SimpleBrowse.h"

#include "MainFrm.h"
#include "TreeContainerWnd.h"
#include "ListContainerWnd.h"
#include "ImgContainerWnd.h"

#include "ThumbnailsDlg.h"
#include "ImageWndDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_CBN_SELCHANGE(IDC_ZOOM, OnSelchangeZoom)
	ON_BN_CLICKED(IDC_BKCOLOR, OnBkcolor)
	ON_COMMAND(ID_OPTIONS, OnOptions)
	ON_BN_CLICKED(IDC_NEXT, OnNext)
	ON_COMMAND(ID_VIEW_THUMBNAIL, OnViewThumbnail)
	ON_UPDATE_COMMAND_UI(ID_VIEW_THUMBNAIL, OnUpdateViewThumbnail)
	ON_BN_CLICKED(IDC_PREV, OnPrev)
	//}}AFX_MSG_MAP
	ON_UPDATE_COMMAND_UI_RANGE(AFX_ID_VIEW_MINIMUM, AFX_ID_VIEW_MAXIMUM, OnUpdateViewStyles)
	ON_COMMAND_RANGE(AFX_ID_VIEW_MINIMUM, AFX_ID_VIEW_MAXIMUM, OnViewStyle)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	m_nCurrentIndex = -2;
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	if (!m_wndDlgBar.Create(this, IDR_MAINFRAME, 
		CBRS_ALIGN_TOP, AFX_IDW_DIALOGBAR))
	{
		TRACE0("Failed to create dialogbar\n");
		return -1;		// fail to create
	}

	if (!m_wndReBar.Create(this) ||
		!m_wndReBar.AddBar(&m_wndToolBar) ||
		!m_wndReBar.AddBar(&m_wndDlgBar))
	{
		TRACE0("Failed to create rebar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Remove this if you don't want tool tips
	m_wndToolBar.SetBarStyle(m_wndToolBar.GetBarStyle() |
		CBRS_TOOLTIPS | CBRS_FLYBY);

	CListContainerWnd* pView = GetRightPane(); 
	CThumbList* pList = &(pView->m_ListCtrl);
	CImgContainerWnd* pView2 = GetMiddlePane(); 
	CImageWnd* pImage = &(pView2->m_ImageWnd);

	float fZoom = pImage->GetZoom();
	CComboBox *pCombo = (CComboBox *)m_wndDlgBar.GetDlgItem(IDC_ZOOM);
	if (pCombo->GetSafeHwnd())
	{
		int nSel = 0;
		CString strZoom;
		for (nSel = 0; nSel < pCombo->GetCount(); nSel++)
		{
			pCombo->GetLBText(nSel, strZoom);
			if (strZoom.CompareNoCase(_T("Fit")) == 0)
			{
				if (fZoom == -1) 
					break;
			}
			else
			{
				float f;
				f = (float)atof(strZoom.GetBuffer(_MAX_PATH));
				strZoom.ReleaseBuffer();
				if (f == fZoom) 
					break;
			}
		}
		if (nSel == pCombo->GetCount())
			nSel -= 1;
		pCombo->SetCurSel(nSel);
	}

	return 0;
}

BOOL CMainFrame::OnCreateClient(LPCREATESTRUCT /*lpcs*/,
	CCreateContext* pContext)
{
	// create splitter window
	if (!m_wndSplitter.CreateStatic(this, 1, 3))
		return FALSE;

	if (!m_wndSplitter.CreateView(0, 0, RUNTIME_CLASS(CTreeContainerWnd), CSize(100, 100), pContext) ||
		!m_wndSplitter.CreateView(0, 1, RUNTIME_CLASS(CImgContainerWnd), CSize(340, 100), pContext) ||
		!m_wndSplitter.CreateView(0, 2, RUNTIME_CLASS(CListContainerWnd), CSize(130, 100), pContext))
	{
		m_wndSplitter.DestroyWindow();
		return FALSE;
	}

	return TRUE;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

CListContainerWnd* CMainFrame::GetRightPane()
{
	CWnd* pWnd = m_wndSplitter.GetPane(0, 2);
	CListContainerWnd* pView = DYNAMIC_DOWNCAST(CListContainerWnd, pWnd);
	return pView;
}

CImgContainerWnd* CMainFrame::GetMiddlePane()
{
	CWnd* pWnd = m_wndSplitter.GetPane(0, 1);
	CImgContainerWnd* pView = DYNAMIC_DOWNCAST(CImgContainerWnd, pWnd);
	return pView;
}

void CMainFrame::OnUpdateViewStyles(CCmdUI* pCmdUI)
{
	// TODO: customize or extend this code to handle choices on the
	// View menu.

	CListContainerWnd* pView = GetRightPane(); 

	// if the right-hand pane hasn't been created or isn't a view,
	// disable commands in our range

	if (pView == NULL)
		pCmdUI->Enable(FALSE);
	else
	{
		BOOL bThumbnail = pView->m_ListCtrl.IsInThumbnailView();

		DWORD dwStyle = pView->m_ListCtrl.GetStyle() & LVS_TYPEMASK;

		// if the command is ID_VIEW_LINEUP, only enable command
		// when we're in LVS_ICON or LVS_SMALLICON mode

		if (pCmdUI->m_nID == ID_VIEW_LINEUP)
		{
			if (dwStyle == LVS_ICON || dwStyle == LVS_SMALLICON)
				pCmdUI->Enable();
			else
				pCmdUI->Enable(FALSE);
		}
		else
		{
			// otherwise, use dots to reflect the style of the view
			pCmdUI->Enable();
			BOOL bChecked = FALSE;

			switch (pCmdUI->m_nID)
			{
			case ID_VIEW_DETAILS:
				bChecked = (dwStyle == LVS_REPORT);
				break;

			case ID_VIEW_SMALLICON:
				bChecked = (dwStyle == LVS_SMALLICON);
				break;

			case ID_VIEW_LARGEICON:
				bChecked = (dwStyle == LVS_ICON);
				break;

			case ID_VIEW_LIST:
				bChecked = (dwStyle == LVS_LIST);
				break;

			default:
				bChecked = FALSE;
				break;
			}

			bChecked = bChecked && !bThumbnail;
			pCmdUI->SetRadio(bChecked ? 1 : 0);
		}
	}
}


void CMainFrame::OnViewStyle(UINT nCommandID)
{
	// TODO: customize or extend this code to handle choices on the
	// View menu.
	CListContainerWnd* pView = GetRightPane();

	// if the right-hand pane has been created and is a CListContainerWnd,
	// process the menu commands...
	if (pView != NULL)
	{
		BOOL bThumbnail = pView->m_ListCtrl.IsInThumbnailView();
		DWORD dwStyle = -1;

		switch (nCommandID)
		{
		case ID_VIEW_LINEUP:
			{
				// ask the list control to snap to grid
				CListCtrl& refListCtrl = (CListCtrl&)pView->m_ListCtrl;
				refListCtrl.Arrange(LVA_SNAPTOGRID);
			}
			break;

		// other commands change the style on the list control
		case ID_VIEW_DETAILS:
			dwStyle = LVS_REPORT;
			break;

		case ID_VIEW_SMALLICON:
			dwStyle = LVS_SMALLICON;
			break;

		case ID_VIEW_LARGEICON:
			dwStyle = LVS_ICON;
			break;

		case ID_VIEW_LIST:
			dwStyle = LVS_LIST;
			break;
		}

		// change the style; window will repaint automatically
		if (dwStyle != -1)
		{
			pView->m_ListCtrl.ModifyStyle(LVS_TYPEMASK, dwStyle);
			// call CThumbListCtrl::LeaveThumbnailView() if leave "thumbnail view"
			 if (bThumbnail)
				pView->m_ListCtrl.LeaveThumbnailView();
			if (bThumbnail && dwStyle == LVS_ICON)
			{
				pView->m_ListCtrl.Arrange(LVA_DEFAULT);
				pView->m_ListCtrl.Invalidate();
			}
			if (dwStyle == LVS_ICON || dwStyle == LVS_SMALLICON)
				pView->m_ListCtrl.Resort();
		}
	}
}

void CMainFrame::OnViewThumbnail() 
{
	// TODO: Add your command handler code here

	CListContainerWnd* pView = GetRightPane();

	// if the right-hand pane has been created and is a CListContainerWnd,
	// process the menu commands...
	if (pView != NULL)
	{
		BOOL bThumbnail = pView->m_ListCtrl.IsInThumbnailView();
		DWORD dwOldStyle = pView->m_ListCtrl.GetStyle() & LVS_TYPEMASK;
		DWORD dwStyle = LVS_ICON;
		pView->m_ListCtrl.ModifyStyle(LVS_TYPEMASK, dwStyle);
		// call CThumbListCtrl::GotoThumbnailView() if entry "thumbnail view"
		pView->m_ListCtrl.GotoThumbnailView();
		if (!bThumbnail && dwOldStyle == LVS_ICON)
		{
			pView->m_ListCtrl.Arrange(LVA_DEFAULT);
			pView->m_ListCtrl.Invalidate();
		}
		pView->m_ListCtrl.Resort();
	}
	
}

void CMainFrame::OnUpdateViewThumbnail(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here

	CListContainerWnd* pView = GetRightPane(); 

	// if the right-hand pane hasn't been created or isn't a view,
	// disable commands in our range

	if (pView == NULL)
		pCmdUI->Enable(FALSE);
	else
	{
		pCmdUI->Enable();

		BOOL bThumbnail = pView->m_ListCtrl.IsInThumbnailView();
		DWORD dwStyle = pView->m_ListCtrl.GetStyle() & LVS_TYPEMASK;
		BOOL bChecked = (dwStyle == LVS_ICON) && bThumbnail;
		pCmdUI->SetRadio(bChecked ? 1 : 0);
	}	
}


void CMainFrame::OnSelchangeZoom() 
{
	// TODO: Add your control notification handler code here
	CListContainerWnd* pView = GetRightPane(); 
	CThumbList* pList = &(pView->m_ListCtrl);
	CImgContainerWnd* pView2 = GetMiddlePane(); 
	CImageWnd* pImage = &(pView2->m_ImageWnd);

	float fZoom = -1;
	CComboBox *pCombo = (CComboBox *)m_wndDlgBar.GetDlgItem(IDC_ZOOM);
	if (pCombo->GetSafeHwnd())
	{
		int nSel = pCombo->GetCurSel();
		CString strZoom;
		pCombo->GetLBText(nSel, strZoom);
		if (strZoom.CompareNoCase(_T("Fit")) == 0)
			fZoom = -1;
		else
		{
			fZoom = (float)atof(strZoom.GetBuffer(_MAX_PATH));
			strZoom.ReleaseBuffer();
		}
		pImage->OnChangeProperties(fZoom, pImage->GetBkground());
	}
}

void CMainFrame::OnBkcolor() 
{
	// TODO: Add your control notification handler code here
	CListContainerWnd* pView = GetRightPane(); 
	CThumbList* pList = &(pView->m_ListCtrl);
	CImgContainerWnd* pView2 = GetMiddlePane(); 
	CImageWnd* pImage = &(pView2->m_ImageWnd);

	COLORREF clrBkground = pImage->GetBkground();
	CColorDialog dlg;
	dlg.m_cc.Flags |= CC_FULLOPEN | CC_RGBINIT;
	dlg.m_cc.rgbResult = clrBkground;
	if (dlg.DoModal() == IDOK)
	{
		clrBkground = dlg.GetColor();
		pImage->OnChangeProperties(pImage->GetZoom(), clrBkground);
	}
	
}

void CMainFrame::OnOptions() 
{
	// TODO: Add your command handler code here
	CListContainerWnd* pView = GetRightPane(); 
	CThumbList* pList = &(pView->m_ListCtrl);
	CImgContainerWnd* pView2 = GetMiddlePane(); 
	CImageWnd* pImage = &(pView2->m_ImageWnd);
	CPropertySheet options(_T("Options"));
	
	CThumbnailsDlg thumbnails;
	thumbnails.m_nChangeThumbSize = pList->IsSaveThumbFile() ? 1 : 0;
	thumbnails.m_nThumbSize = ::GetThumbSize().cx;

	CImageWndDlg imagewnd;
	imagewnd.m_fZoom = pImage->GetZoom();
	imagewnd.m_clrBkground = pImage->GetBkground();
	
	options.AddPage(&thumbnails);
	options.AddPage(&imagewnd);
	if(options.DoModal() == IDOK)
	{
		int nChangeThumbSize = thumbnails.m_nChangeThumbSize;
		int nThumbSize = thumbnails.m_nThumbSize;
		BOOL bSaveThumbFile = (nChangeThumbSize == 1) ? TRUE : FALSE;
		pList->OnChangeThumbSize(bSaveThumbFile, CSize(nThumbSize, nThumbSize));

		float fZoom = imagewnd.m_fZoom;
		COLORREF clrBkground = imagewnd.m_clrBkground;
		pImage->OnChangeProperties(fZoom, clrBkground);
	}
	
}

void CMainFrame::OnNext() 
{
	// TODO: Add your control notification handler code here
	CListContainerWnd* pView = GetRightPane(); 
	CThumbList* pList = &(pView->m_ListCtrl);
	CImgContainerWnd* pView2 = GetMiddlePane(); 
	CImageWnd* pImage = &(pView2->m_ImageWnd);

	BOOL bMultiSelect = FALSE;
	int nCount = 0;
	bMultiSelect = ((nCount = pList->GetSelectedCount()) > 1 ? TRUE : FALSE);
	if (!bMultiSelect)
		nCount = pList->GetItemCount();
	if (nCount <= 0)
		return;

	int nFirst = 0, nNext = 0;
	if (m_nCurrentIndex == -2)
	{
		nFirst = pList->GetNextItem(-1, LVNI_SELECTED);
		m_nCurrentIndex = nFirst;
	}

	if (bMultiSelect)
	{
		// Select multiple images, just see these files
		nNext = pList->GetNextItem(m_nCurrentIndex, LVNI_SELECTED);
		if (nNext == -1)
			nNext = 0;
		if (nNext != m_nCurrentIndex)
		{
			CString strFullName;
			CThumbItemInfo* pThumbItem = (CThumbItemInfo* )pList->GetItemData(nNext);
			strFullName = pThumbItem->GetFullName();
			pImage->SeeFile(strFullName);
		}
	}
	else
	{
		// No select or just select one image, see all files
		nNext = pList->GetNextItem(m_nCurrentIndex, LVNI_ALL);
		if (nNext == -1)
			nNext = 0;		// Loop
		if (nNext != m_nCurrentIndex && nNext >= 0 && nNext < nCount)
		{
			pList->SetItemState(m_nCurrentIndex, 0, LVIS_SELECTED | LVIS_FOCUSED);
			// Select the item, that will cause a LVN_ITEMCHANGED message, the response to this
			// message is to call SeeFile()
			pList->SetItemState(nNext, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
		}
	}
	
	m_nCurrentIndex = nNext;
		
}

void CMainFrame::OnPrev() 
{
	// TODO: Add your control notification handler code here
	CListContainerWnd* pView = GetRightPane(); 
	CThumbList* pList = &(pView->m_ListCtrl);
	CImgContainerWnd* pView2 = GetMiddlePane(); 
	CImageWnd* pImage = &(pView2->m_ImageWnd);

	BOOL bMultiSelect = FALSE;
	int nCount = 0;
	bMultiSelect = ((nCount = pList->GetSelectedCount()) > 1 ? TRUE : FALSE);
	if (!bMultiSelect)
		nCount = pList->GetItemCount();
	if (nCount <= 0)
		return;
	
	int nFirst = 0, nPrev = 0;
	if (m_nCurrentIndex == -2)
	{
		nFirst = pList->GetNextItem(-1, LVNI_SELECTED);
		m_nCurrentIndex = nFirst;
	}

	// Oh, my god, there is no GetPrevItem()
	CArray<int, int> aIndexs;
	int i = 0, nIndex = -1;
	if (bMultiSelect)
	{
		// Select multiple images, just see these files
		// Construct index array
		for (i = 0; i < nCount; i++)
		{
			nIndex = pList->GetNextItem(nIndex, LVNI_SELECTED);
			aIndexs.Add(nIndex);
		}
		// Find current position
		for (i = aIndexs.GetUpperBound(); i >= 0; i--)
		{
			if (aIndexs[i] == m_nCurrentIndex)
				break;
		}
		i -= 1;		// Prev one
		if (i <= -1)
			i = aIndexs.GetUpperBound();
		if (i >= 0)
			nPrev = aIndexs[i];

		if (nPrev != m_nCurrentIndex && nPrev >= 0 && nPrev < nCount)
		{
			CString strFullName;
			CThumbItemInfo* pThumbItem = (CThumbItemInfo* )pList->GetItemData(nPrev);
			strFullName = pThumbItem->GetFullName();
			pImage->SeeFile(strFullName);
		}
	}
	else
	{
		// No select or just select one image, see all files
		for (i = 0; i < nCount; i++)
		{
			nIndex = pList->GetNextItem(nIndex, LVNI_ALL);
			aIndexs.Add(nIndex);
		}
		for (i = aIndexs.GetUpperBound(); i >= 0; i--)
		{
			if (aIndexs[i] == m_nCurrentIndex)
				break;
		}
		i -= 1;
		if (i <= -1)
			i = aIndexs.GetUpperBound();
		if (i >= 0)
			nPrev = aIndexs[i];

		if (nPrev != m_nCurrentIndex && nPrev >= 0 && nPrev < nCount)
		{
			pList->SetItemState(m_nCurrentIndex, 0, LVIS_SELECTED | LVIS_FOCUSED);
			// Select the item, that will cause a LVN_ITEMCHANGED message, the response to this
			// message is to call SeeFile()
			pList->SetItemState(nPrev, LVIS_SELECTED | LVIS_FOCUSED, LVIS_SELECTED | LVIS_FOCUSED);
		}
	}
	
	m_nCurrentIndex = nPrev;
}
