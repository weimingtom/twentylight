// ImgContainerWnd.cpp : implementation file
//

#include "stdafx.h"
#include "SimpleBrowse.h"
#include "ImgContainerWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define IDC_IMAGE_WND  1
/////////////////////////////////////////////////////////////////////////////
// CImgContainerWnd

IMPLEMENT_DYNCREATE(CImgContainerWnd, CView)

CImgContainerWnd::CImgContainerWnd()
{
}

CImgContainerWnd::~CImgContainerWnd()
{
}


BEGIN_MESSAGE_MAP(CImgContainerWnd, CView)
	//{{AFX_MSG_MAP(CImgContainerWnd)
	ON_WM_CREATE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CImgContainerWnd drawing

void CImgContainerWnd::OnDraw(CDC* pDC)
{
	CDocument* pDoc = GetDocument();
	// TODO: add draw code here
}

/////////////////////////////////////////////////////////////////////////////
// CImgContainerWnd diagnostics

#ifdef _DEBUG
void CImgContainerWnd::AssertValid() const
{
	CView::AssertValid();
}

void CImgContainerWnd::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CImgContainerWnd message handlers

int CImgContainerWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_ImageWnd.Create(NULL, _T("ImageWnd"), WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_HSCROLL,
		CRect(0,0,0,0), this, IDC_IMAGE_WND))
	{
		TRACE0("Unable to create image window.\n");
		return -1;
	}

	return 0;
}

void CImgContainerWnd::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	if (m_ImageWnd.GetSafeHwnd())
		m_ImageWnd.MoveWindow(0,0,cx,cy);
	
}

