// ThumbList.cpp : implementation file
//

#include "stdafx.h"
#include "SimpleBrowse.h"
#include "ThumbList.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CSize g_sizeThumbSize;

CSize GetThumbSize()
{
	return g_sizeThumbSize;
}

void SetThumbSize(CSize sizeThumbSize)
{
	g_sizeThumbSize = sizeThumbSize;
}

#define SHOW_FILE_SIZE 0
/////////////////////////////////////////////////////////////////////////////
// CThumbList
CMutex CThumbList::g_MutexThumb;

// File color table, like ACDSee
FILECOLOR FileColors[] = 
{
	_T(".awd"),			0x00FFFFFF,
	_T(".bmp"),			0x00FFE7E7,
	_T(".dcx"),			0x00FFFFFF,
	_T(".dib"),			0x00FFE7E7,
	_T(".eps"),			0x00FFFFFF,
	_T(".gif"),			0x00D6EBD6,
	_T(".ico"),			0x00FFFFFF,
	_T(".jpg"),			0x00CEEBEF,
	_T(".jpe"),			0x00CEEBEF,
	_T(".jif"),			0x00CEEBEF,
	_T(".jpeg"),		0x00CEEBEF,
	_T(".mac"),			0x00FFFFFF,
	_T(".pcd"),			0x00FFFFFF,
	_T(".pcx"),			0x00E7E7EF,
	_T(".pct"),			0x00FFFFFF,
	_T(".pic"),			0x00FFFFFF,
	_T(".png"),			0x00D6DFE7,
	_T(".ppm"),			0x00FFFFFF,
	_T(".psd"),			0x00DEFFFF,
	_T(".ras"),			0x00FFFFFF,
	_T(".rle"),			0x00FFFFFF,
	_T(".tga"),			0x00FFFFE7,
	_T(".tif"),			0x00E7CBBD,
	_T(".tiff"),		0x00E7CBBD,
	_T(".emf"),			0x00D6D3D6,
	_T(".iff"),			0x00EFEBFF,
	_T(".wmf"),			0x00B5B6B5
};

COLORREF ExtToColor(CString strExt, FILECOLOR* pFileColorTable, int nTableLength)
{
	COLORREF clrRes = 0x00FFFFFF;
	FILECOLOR* pCurrItem;
	int i = 0;
	for (i = 0; i < nTableLength; i++)
	{
		pCurrItem = pFileColorTable + i;
		if (strExt.CompareNoCase(pCurrItem->szFileExt) == 0)
		{
			clrRes = pCurrItem->clrColor;
			break;
		}
	}
	return clrRes;
}

CThumbList::CThumbList()
{
	g_sizeThumbSize = CSize(80, 80);

	m_strImageFormat = "awd;bmp;dcx;dib;eps;gif;ico;jpg;jpe;jif;jpeg;mac;pcd;pcx;pct;pic;png;ppm;psd;ras;rle;tga;tif;tiff";
	m_bInitColumns = FALSE;
	m_sizeThumbSize = CSize(80, 80);
	m_lCharHeight = 12;
	m_pImageList = 0;
	m_bLVS_THUMBNAIL = false;
	m_clrNormalBk = ::GetSysColor(COLOR_WINDOW);

	m_pThumbThread = NULL;
	m_ThumbThreadInfo.pThumbObj = NULL;
	m_bSuspendThumbThread = false;

	m_strBrowseFile = "brwseimg.tf";
	m_strFileID = "Image Thumbnail File";
	m_bModified = FALSE;

	m_bSaveThumbFile = FALSE;
	m_nSortColumn = 0; 
	m_bSortAscending = TRUE;
}

CThumbList::~CThumbList()
{
	CleanUpThumbObjList();
}

IMPLEMENT_DYNCREATE(CThumbList, CListCtrl)

BEGIN_MESSAGE_MAP(CThumbList, CListCtrl)
	//{{AFX_MSG_MAP(CThumbList)
	ON_WM_CREATE()
	ON_NOTIFY_REFLECT(LVN_GETDISPINFO, OnGetDispInfo)
	ON_NOTIFY_REFLECT(NM_CUSTOMDRAW, OnCustomDraw)
	ON_NOTIFY_REFLECT(LVN_DELETEITEM, OnDeleteitem)
	ON_MESSAGE(WM_USER_COMPLETE_AND_IDLE,OnCompleteAndIdle)
	ON_WM_DESTROY()
	ON_WM_VSCROLL()
	ON_WM_HSCROLL()
	ON_NOTIFY_REFLECT(LVN_COLUMNCLICK, OnColumnclick)
//	ON_NOTIFY_REFLECT(LVN_ITEMCHANGED, OnItemchanged)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CThumbList message handlers

CString CThumbList::GetImageFormatString()
{
	return m_strImageFormat;
}

void CThumbList::SetImageFormatString(CString strImageFormat)
{
	m_strImageFormat = strImageFormat;
}

int CThumbList::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CListCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	if (OnCreateList(lpCreateStruct) == -1)
		return -1;
	
	return 0;
}

int CThumbList::OnCreateList(LPCREATESTRUCT lpCreateStruct) 
{
	if (!BuildColumns())
		return -1;
	
	// TODO: Add your specialized creation code here
	CreateImageLists();
	
	// Now, create the thumb thread
	BeginThumbThread();

	return 0;
}

BOOL CThumbList::BuildColumns()
{
	if(!m_bInitColumns)
	{
		CString strItem1= _T("Name");
		CString strItem2= _T("Size");
		CString strItem3= _T("Type");
		CString strItem4= _T("Modified");

		// insert two columns (REPORT mode) and modify the new header items
		InsertColumn(0, strItem1, LVCFMT_LEFT, 150, 0);
		InsertColumn(1, strItem2, LVCFMT_RIGHT,	80, 1);
		InsertColumn(2, strItem3, LVCFMT_LEFT, 125, 2);
		InsertColumn(3, strItem4, LVCFMT_LEFT, 150, 3);  

		m_bInitColumns = TRUE;
	}
	return m_bInitColumns;
}

void CThumbList::CreateImageLists()
{
	// add LVS_SHAREIMAGELISTS, otherwise will destroy system image list(Windows Explorer will
	// can not show the file icon)
	ModifyStyle(0, LVS_SHAREIMAGELISTS | LVS_AUTOARRANGE);

	// Large and small icon image list
	GetSystemImageList(&m_SmallIcons, &m_LargeIcons);
	SetImageList(&m_SmallIcons, LVSIL_SMALL);
	SetImageList(&m_LargeIcons, LVSIL_NORMAL);

	// Thumbnail icon image list
	TEXTMETRIC tm;
	CDC *pDC = GetDC();
	pDC->GetTextMetrics(&tm);
	ReleaseDC(pDC);
	m_lCharHeight = tm.tmHeight;

	CreateThumbViewImageList();
}

void CThumbList::GetSystemImageList(CImageList * pSmallList, CImageList * pLargeList)
{
	//image list setup
	SHFILEINFO  ssfi, lsfi;
    
	// Get a handle to the system small icon list 
	HIMAGELIST hSystemSmallImageList = (HIMAGELIST)
		::SHGetFileInfo((LPCTSTR)_T("C:\\"), 0, &ssfi,
		sizeof(SHFILEINFO), SHGFI_SYSICONINDEX | SHGFI_SMALLICON); 

	// Attach it to the small image list 
	// DON'T FORGET TO PUT pSmallList->Detach(); in your destructor
 	pSmallList->Attach(hSystemSmallImageList);

	// Get a handle to the system large icon list 
	HIMAGELIST hSystemLargeImageList =	(HIMAGELIST)
		::SHGetFileInfo((LPCTSTR)_T("C:\\"), 0,	&lsfi,
		sizeof(SHFILEINFO),	SHGFI_SYSICONINDEX | SHGFI_ICON); 

	// Attach it to the large image list 
	// DON'T FORGET TO PUT pLargeList->Detach(); in your destructor
 	pLargeList->Attach(hSystemLargeImageList); 
}

void CThumbList::CreateThumbViewImageList()
{
	m_sizeThumbSize = ::GetThumbSize();

	m_pImageList = new CImageList();
	CSize sizeIcon;
	sizeIcon.cx = m_sizeThumbSize.cx + 
		INTERSPACE * 2;// +	// for space
	if (SHOW_FILE_SIZE == 1)
	{
	sizeIcon.cy = m_sizeThumbSize.cy + 
		m_lCharHeight * 2;// + // for text: "1/12" at top and "640x480x16M" at bottom
	}
	else
	{
	sizeIcon.cy = m_sizeThumbSize.cy + 
		m_lCharHeight + INTERSPACE;// +// for text: "640x480x16M" at bottom and space at top
	}
	// Note: if you create an image list use 32x32, then GetItemRect(..., LVIR_ICON), the return size will
	// be 48x36, (32+16)x(32+4), it means that if I want an 80x80 size thumb, I just need to
	// create an image list use (80-16)x(80-4).
	m_pImageList->Create(sizeIcon.cx - 16, sizeIcon.cy - 4, ILC_COLOR,  1, 1);
}

CWinThread* CThumbList::BeginThumbThread()
{
	if(m_pThumbThread == NULL)
	{
		m_hEventWantKill = CreateEvent(NULL, FALSE, FALSE, NULL); // auto reset, initially don't want kill
		m_hEventIsDead = CreateEvent(NULL, FALSE, FALSE, NULL); // auto reset, initially is not dead
		m_hEventHaveWork = CreateEvent(NULL, FALSE, FALSE, NULL); // auto reset, initially no work
		m_hEventIsIdle = CreateEvent(NULL, FALSE, TRUE, NULL); // auto reset, initially is idle

		m_ThumbThreadInfo.hEventWantKill = m_hEventWantKill;
		m_ThumbThreadInfo.hEventIsDead = m_hEventIsDead;
		m_ThumbThreadInfo.hEventHaveWork = m_hEventHaveWork;
		m_ThumbThreadInfo.hEventIsIdle = m_hEventIsIdle;
		m_ThumbThreadInfo.pWndNotify = this;
		m_ThumbThreadInfo.bChangeDir = true;

		m_pThumbThread =
			AfxBeginThread(ThumbThreadProc, &m_ThumbThreadInfo);//,THREAD_PRIORITY_BELOW_NORMAL);//LOWEST);
		if (!m_bLVS_THUMBNAIL)
		{
			// If is not in thumbnail view, suspend it
			if (!m_bSuspendThumbThread)
			{
				m_pThumbThread->SuspendThread();
				m_bSuspendThumbThread = true;
			}
		}
	}
	return m_pThumbThread;
}

void CThumbList::BrowseFolder(CString strFolder)
{
	if (strFolder.CompareNoCase(m_strFolder) == 0)
		return;

	Clean();
	m_strFolder = strFolder;
	Init();
}

void CThumbList::SetModifiedFlag(BOOL bModified)
{
	m_bModified = bModified;
}

BOOL CThumbList::IsModified()
{
	return m_bModified;
}

void CThumbList::Init()
{
	FillListCtrl();
	// begin to create thumbnail
	CreateThumbnails();
}

void CThumbList::FillListCtrl()
{	
	if(m_strFolder.IsEmpty())
		return;
	if(_access(m_strFolder, 04) == -1)
		return;

	m_bFillCompleted = FALSE;
	CFileFind finder;
	CString strFindFolder = m_strFolder + "*.*";
	BOOL bWorking = finder.FindFile(strFindFolder,0);
	int iItem = 0;
	while(bWorking)
	{
		bWorking = finder.FindNextFile();
		if(finder.IsDirectory() || finder.IsDots())
			continue;		// Not a file
		
		CString strFoundFile = finder.GetFilePath();
		CImgFileInfo FileInfo(strFoundFile);
		if(!FileInfo.IsImageFile(GetImageFormatString()))
			continue;		// Not an image file

		CThumbItemInfo *pItemInfo = new CThumbItemInfo(strFoundFile);
		if (pItemInfo != 0)
		{
			int iIcon = pItemInfo->GetIconIndex();
			int iActualItem = InsertItem(iItem, LPSTR_TEXTCALLBACK, iIcon);
			if (iActualItem != -1)
			{
				SetItemData(iActualItem, (DWORD)pItemInfo);
			}
			iItem++;
		}
	}
	finder.Close();
	m_bFillCompleted = TRUE;

	CSingleLock SingleLock(&g_MutexThumb);
	SingleLock.Lock();
	m_ThumbThreadInfo.bChangeDir = true;
	SingleLock.Unlock();
}

void CThumbList::CreateThumbnails()
{
	if (m_bSuspendThumbThread)
		return;

	int nCount = GetItemCount();
	if(nCount > 0)
	{
		THUMBTHREADINFO ThreadInfo;
		// To check which file should turn to create thumbnail
		if(GetThumbCreateInfo(&ThreadInfo))
		{
			// find out at least one item's thumbnail is not ready
			::WaitForSingleObject(m_hEventIsIdle, INFINITE);
			CSingleLock SingleLock(&g_MutexThumb);
			SingleLock.Lock();
			m_ThumbThreadInfo.nItem = ThreadInfo.nItem;
			m_ThumbThreadInfo.strFullName = ThreadInfo.strFullName;
			if (m_ThumbThreadInfo.pThumbObj)
			{
				delete m_ThumbThreadInfo.pThumbObj;
			}
			m_ThumbThreadInfo.pThumbObj = NULL;
			SingleLock.Unlock();

			// signal the envent, tell the thumb thread have work to do
			SetEvent(m_hEventHaveWork);
		}
		else
		{
			// All files in this folder are process, then...
			// still have thumb obj in list? if yes, means that the image file was deleted
			if (m_listThumbObj.GetCount() > 0)
				SetModifiedFlag(TRUE);
			// cleanup thumb obj list, so can delete those non-exist image file's thumbnail
			CleanUpThumbObjList();
			// if finish create thumbnails, save to the browse file
			SaveBrowseFile();
		}
	}
}

BOOL CThumbList::GetThumbCreateInfo(THUMBTHREADINFO *pThreadInfo)
{
	BOOL bThumbsNotReady = FALSE;
	int nCount = GetItemCount();
	int nFirstVisible = GetFirstVisibleItem();

	// look forward to find out the item that thumbnail is not ready
	for(int i = nFirstVisible; i < nCount; i++)
	{
		CThumbItemInfo* pThumbItem = (CThumbItemInfo *)GetItemData(i);
		if(!pThumbItem->IsThumbReady() && 
			!pThumbItem->HaveTryToCreateThumb())
		{
			// return the information about this item
			CString strFullName = pThumbItem->GetFullName();;
			pThreadInfo->nItem = i;
			pThreadInfo->strFullName = strFullName;
			pThreadInfo->pThumbObj = NULL;
			bThumbsNotReady = TRUE;
			break;
		}
	}
	// look backward to find out the item that thumbnail is not ready
	if(!bThumbsNotReady)
	{
		for(int i = nFirstVisible - 1; i >= 0; i--)
		 {
			CThumbItemInfo* pThumbItem = (CThumbItemInfo *)GetItemData(i);
			if(!pThumbItem->IsThumbReady() &&
				!pThumbItem->HaveTryToCreateThumb())
			{
				CString strFullName = pThumbItem->GetFullName();;
				pThreadInfo->nItem = i;
				pThreadInfo->strFullName = strFullName;
				pThreadInfo->pThumbObj = NULL;
				bThumbsNotReady = TRUE;
				bThumbsNotReady = TRUE;
				break;
			}
		 }
	}
	return bThumbsNotReady;
}

int CThumbList::GetFirstVisibleItem()
{
	int nCount = GetItemCount();
	int nItem = 0;
	CRect rectItem;
	for(nItem = 0; nItem < nCount; nItem++)
	{
		GetItemRect(nItem, &rectItem, LVIR_ICON);
		if(rectItem.bottom >= 0 )
			break;
	}
	m_nFirstVisibleItem = nItem;
	if(m_nFirstVisibleItem >= nCount)
		m_nFirstVisibleItem = 0;

	return m_nFirstVisibleItem;
}

UINT CThumbList::ThumbThreadProc(LPVOID pParam)
{
	THUMBTHREADINFO *pThreadInfo = (THUMBTHREADINFO *)pParam;
	CSingleLock SingleLock(&g_MutexThumb);
	CThumbList *pWnd = (CThumbList *)pThreadInfo->pWndNotify;
	while(TRUE)
	{
		// sleep until the main thread tell me to create thumbnail
		if (WaitForSingleObject(pThreadInfo->hEventHaveWork, INFINITE)
			!= WAIT_OBJECT_0)
			break;

		// check if the main thread want to kill me?
		if (WaitForSingleObject(pThreadInfo->hEventWantKill, 0)
			== WAIT_OBJECT_0)
			break; // Terminate this thread by existing the proc.

		SingleLock.Lock();
		CString strFullName = pThreadInfo->strFullName;
		if (pThreadInfo->bChangeDir)
		{
			// If change to another dir, need to read "brwseimg.tf" file
			pWnd->ReadBrowseFile();
			pThreadInfo->bChangeDir = false;
		}

		{
			CThumbObj *pThumbObjGiveBack = 0;
			//check if this's thumbnail is in the browse file
			POSITION pos = pWnd->m_listThumbObj.GetHeadPosition();
			while(pos != NULL)
			{
				CThumbObj *pThumbObj = pWnd->m_listThumbObj.GetNext(pos);
				CSHFileInfo sfFile(strFullName);
				CString strFileName = sfFile.GetFileName();
				CString strObjFileName = pThumbObj->GetFileName();
				CString strObjFullName = pThumbObj->GetFullName();
				if(strObjFileName.CompareNoCase(strFileName) == 0)
				{
					CFileStatus fs;
					CFile::GetStatus(strFullName, fs);
					CTime fsTime = fs.m_mtime;
					CTimeSpan timeDelay(0, 0, 0, 10);	//10 seconds
					CFile::GetStatus(strObjFullName, fs);
					if(fsTime > (fs.m_mtime + timeDelay))
					{
						// image file is newer than the thumbnail record
						POSITION posTemp;
						posTemp = pWnd->m_listThumbObj.Find(pThumbObj);
						if(pThumbObj != NULL)
						{
							delete pThumbObj;
							pThumbObj = 0;
						}
						if(posTemp != NULL)
							pWnd->m_listThumbObj.RemoveAt(posTemp);
						pWnd->SetModifiedFlag(TRUE);
					}
					else
					{
						// image file no changed
						pThumbObjGiveBack = pThumbObj;
						POSITION posTemp;
						posTemp = pWnd->m_listThumbObj.Find(pThumbObj);
						if(posTemp != NULL)
							pWnd->m_listThumbObj.RemoveAt(posTemp);
						pThumbObj = 0;
					}
					break;
				}
			}

			// if no, create it
			if (pThumbObjGiveBack == 0)
			{
				pThumbObjGiveBack = new CThumbObj(strFullName);
				pThumbObjGiveBack->CreateThumbnail();
				pWnd->SetModifiedFlag(TRUE);
			}

			if(pThreadInfo->pThumbObj)
			{
				delete pThreadInfo->pThumbObj;
			}
			pThreadInfo->pThumbObj = pThumbObjGiveBack;
			SingleLock.Unlock();

			// notify main thread that one thumbnail was created complete, and I am idle now.
			SetEvent(pThreadInfo->hEventIsIdle);
			pWnd->PostMessage(WM_USER_COMPLETE_AND_IDLE, 0, 0);
		}
	}
	// let me clean up
	SingleLock.Lock();
	if (pThreadInfo->pThumbObj)
	{
		delete pThreadInfo->pThumbObj;
		pThreadInfo->pThumbObj = 0;
	}
	SingleLock.Unlock();
	// I am dead!
	SetEvent(pThreadInfo->hEventIsDead);
	return 0;
}

BOOL CThumbList::ReadBrowseFile()
{
	if (m_bSaveThumbFile == FALSE)
		return FALSE;

	CFileFind finder;
	CFile fileBrowse;
	//does it exist?
	CString strPathName;
	strPathName = m_strFolder + m_strBrowseFile;
	if(finder.FindFile(strPathName))
	{
		BOOL bOpenSucceed = true;
		try
		{
			bOpenSucceed = fileBrowse.Open(strPathName, CFile::modeRead);
			//create a archive and then use it to serialize data
			if(bOpenSucceed)
			{
				DWORD dwFileLength = fileBrowse.GetLength();
				int nMinLength = m_strFileID.GetLength();
				if (dwFileLength > (DWORD)nMinLength)
				{
					CArchive ar(&fileBrowse, CArchive::load);
					BOOL bIsThumbnailFile = false;
					CString strFileID;
					ar >> strFileID;
					if(strFileID.CompareNoCase(m_strFileID) == 0)
					{
						bIsThumbnailFile = true;
					}
					if(bIsThumbnailFile)
						m_listThumbObj.Serialize(ar);
					ar.Close();
				}
				fileBrowse.Close();
			}
		}
		catch(CException* e)
		{
			e->ReportError();
			throw;
		}
	}
	return true;
}

LRESULT CThumbList::OnCompleteAndIdle(WPARAM wParam, LPARAM lParam)
{
	int nCount = GetItemCount();
	CSingleLock SingleLock(&g_MutexThumb);
	SingleLock.Lock();

	int nItem = m_ThumbThreadInfo.nItem;
	int nRedrawItem = 0;
	BOOL bNeedRedraw = FALSE;

	if(nItem < nCount)
	{
		CThumbItemInfo* pThumbItem = (CThumbItemInfo *)GetItemData(nItem);
		CString strFileName = pThumbItem->GetFullName();
		if(m_ThumbThreadInfo.strFullName.CompareNoCase(strFileName) == 0 &&
			m_ThumbThreadInfo.pThumbObj)
		{
			// receive the thumbnail data object and attach pointer to item
			pThumbItem->SetThumb(m_ThumbThreadInfo.pThumbObj);
			m_ThumbThreadInfo.pThumbObj = NULL;
			if (pThumbItem->IsThumbReady())
				bNeedRedraw = TRUE;
			nRedrawItem = nItem;
		}
		else
		{
			if(m_ThumbThreadInfo.pThumbObj)
			{
				delete m_ThumbThreadInfo.pThumbObj;
			}
			m_ThumbThreadInfo.pThumbObj = NULL;
		}
	}
	else
	{
		if(m_ThumbThreadInfo.pThumbObj)
		{
			delete m_ThumbThreadInfo.pThumbObj;
		}
		m_ThumbThreadInfo.pThumbObj = NULL;
	}

	SingleLock.Unlock();

	if(bNeedRedraw)
	{
     	long lStyle = GetWindowLong(m_hWnd, GWL_STYLE) & LVS_TYPEMASK;
        if((lStyle == LVS_ICON) && m_bLVS_THUMBNAIL)
		{
		   RedrawItems(nRedrawItem, nRedrawItem);
		   UpdateWindow();
		}
	}

	// continue to the next one
	CreateThumbnails();

	return 0;
}

void CThumbList::OnGetDispInfo(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NMLVDISPINFO* pDispInfo = (NMLVDISPINFO*)pNMHDR;
	if (pDispInfo->item.mask & LVIF_TEXT) 
	{
		CThumbItemInfo* pThumbItem = reinterpret_cast<CThumbItemInfo*>(pDispInfo->item.lParam);
		if (pThumbItem)
		{
			// Display info according the Columns (see BuildColumns())
			switch (pDispInfo->item.iSubItem) 
			{
			case 0 :
				lstrcpy(pDispInfo->item.pszText, pThumbItem->GetFileName());
				break;
			case 1 :
				lstrcpy(pDispInfo->item.pszText, pThumbItem->GetFileSize());
				break;
			case 2:
				lstrcpy(pDispInfo->item.pszText, pThumbItem->GetDescription());
				break;
			case 3:
				lstrcpy(pDispInfo->item.pszText, pThumbItem->GetLastWriteTime());
				break;
			}
		}
	}
	*pResult = 0;
}

void CThumbList::OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult) 
{
	long lStyle = GetWindowLong(m_hWnd, GWL_STYLE) & LVS_TYPEMASK;
	NMLVCUSTOMDRAW *pCD = (NMLVCUSTOMDRAW*)pNMHDR;
	// By default set the return value to do the default behavior.
	*pResult = 0;

	CRect rectClient;
	GetClientRect(&rectClient);
	switch( pCD->nmcd.dwDrawStage )
	{
	case CDDS_PREPAINT:  // First stage (for the whole control)
		// Tell the control we want to receive drawing messages  
		// for drawing items.
		*pResult = CDRF_NOTIFYITEMDRAW;
		// The next stage is handled in the default:
		break;
	case CDDS_ITEMPREPAINT:
		{
			int nItem = pCD->nmcd.dwItemSpec;

			CThumbItemInfo* pThumbItem = (CThumbItemInfo *)pCD->nmcd.lItemlParam;
			CDC* pDC = CDC::FromHandle(pCD->nmcd.hdc);
			if(lStyle == LVS_ICON && m_bLVS_THUMBNAIL)
			{
				CRect rectIcon;
				GetItemRect( nItem, &rectIcon, LVIR_ICON);
				CRect rectLabel;
				GetItemRect(nItem,&rectLabel,LVIR_LABEL);
				CRect rectBounds;
				GetItemRect(nItem, &rectBounds, LVIR_BOUNDS);

				CRect rectTest1;
				rectTest1.IntersectRect(rectClient, rectBounds);
				if (rectTest1.IsRectEmpty())
				{
					// This item don't in the client rect
					*pResult = CDRF_DODEFAULT;
					return;
				}

				int nSaveDC = pDC->SaveDC();
				pDC->RestoreDC(nSaveDC);
				// draw icon
				if(!pThumbItem->IsThumbReady())
				{
					int nIcon = pThumbItem->GetIconIndex();
					m_LargeIcons.Draw(pDC, 
						nIcon,
						CPoint(rectIcon.left+(rectIcon.Width()-32)/2,rectIcon.top+(rectIcon.Height()-32)/2),
						ILD_TRANSPARENT);
				}
				else
				{
					// draw edge
/*					POINT points[8];
					points[0].x = rectIcon.left + 3;
					points[0].y = rectIcon.bottom;
					points[1].x = rectIcon.left;
					points[1].y = rectIcon.bottom - 3;
					points[2].x = rectIcon.left;
					points[2].y = rectIcon.top + 3;
					points[3].x = rectIcon.left + 3;
					points[3].y = rectIcon.top;
					points[4].x = rectIcon.right - 3;
					points[4].y = rectIcon.top;
					points[5].x = rectIcon.right;
					points[5].y = rectIcon.top + 3;
					points[6].x = rectIcon.right;
					points[6].y = rectIcon.bottom - 3;
					points[7].x = rectIcon.right - 3;
					points[7].y = rectIcon.bottom;

					CPen *pOldPen;
					pOldPen = (CPen*)pDC->SelectStockObject(WHITE_PEN);

					//paint white edge
					pDC->MoveTo(points[0]);
					pDC->LineTo(points[1]);
					pDC->LineTo(points[2]);
					pDC->LineTo(points[3]);
					pDC->LineTo(points[4]);

					//paint black edge
					pDC->SelectStockObject(BLACK_PEN);
					pDC->LineTo(points[5]);
					pDC->LineTo(points[6]);
					pDC->LineTo(points[7]);
					pDC->LineTo(points[0]);
				
					pDC->SelectObject(pOldPen);
*/
					pDC->Draw3dRect(rectIcon, RGB(255, 255, 255), RGB(0, 0, 0));

					// draw "1/12" information
					CString strInfo;
					CRect rectInfo;
					int n1K = 1 << 10, n1M = 1 << 20;
					if (SHOW_FILE_SIZE == 1)
					{
						CString strFileSize;
						int nFileSize = pThumbItem->GetFileSizeInt();
						float fFileSize;
						if (nFileSize < n1K)
						{
							strFileSize.Format("%d", nFileSize);
						}
						else if (n1K <= nFileSize && nFileSize < n1M)
						{
							fFileSize = (float)nFileSize / (float)n1K;
							strFileSize.Format("%.1fK", fFileSize);
						}
						else
						{
							fFileSize = (float)nFileSize / (float)n1M;
							strFileSize.Format("%.1fM", fFileSize);
						}
						strInfo.Format("%s, %d/%d", strFileSize, nItem + 1, GetItemCount());
						strInfo.Format("%d/%d", nItem + 1, GetItemCount());
						rectInfo.SetRect(rectIcon.left + 0 + INTERSPACE,
							rectIcon.top + 0,
							rectIcon.right - 0 - INTERSPACE,
							rectIcon.top + 0 + m_lCharHeight);
						pDC->DrawText(strInfo, rectInfo, DT_LEFT | DT_VCENTER | DT_SINGLELINE | DT_WORD_ELLIPSIS);
					}

					// draw thumbnail
					CRect rectThumb;
					if (SHOW_FILE_SIZE == 1)
					{
						rectThumb.SetRect(rectIcon.left + 0 + INTERSPACE + 0,
							rectIcon.top + 0 + m_lCharHeight + 0,
							rectIcon.right - 0 - INTERSPACE - 0,
							rectIcon.bottom - 0 - m_lCharHeight - 0);
					}
					else
					{
						rectThumb.SetRect(rectIcon.left + 0 + INTERSPACE + 0,
							rectIcon.top + 0 + INTERSPACE + 0,
							rectIcon.right - 0 - INTERSPACE - 0,
							rectIcon.bottom - 0 - m_lCharHeight - 0);
					}
					pThumbItem->PaintThumb(pDC, rectThumb);

					// draw image thumb edge
					CSize sizeImg = pThumbItem->GetThumb()->GetImgSize();
					CRect rectImg(CPoint(0, 0), sizeImg);
					rectImg.OffsetRect(rectThumb.CenterPoint() - rectImg.CenterPoint());
					pDC->Draw3dRect(rectImg, RGB(128, 128, 128), RGB(255, 255, 255));

					// draw image size and color information
					BITMAPINFOHEADER* pBmpInfo = pThumbItem->GetThumb()->GetOrgImgInfoHeader();
					CString strColors;
					int nColors = 1 << (pBmpInfo->biBitCount * pBmpInfo->biPlanes);
					if (nColors < n1K)
						strColors.Format("%d", nColors);
					else if (n1K <= nColors && nColors < n1M)
						strColors.Format("%dK", (nColors >> 10));
					else
						strColors.Format("%dM", (nColors >> 20));
					strInfo.Format("%dx%dx%s",
						pBmpInfo->biWidth,
						pBmpInfo->biHeight,
						strColors);
					rectInfo.SetRect(rectIcon.left + 0 + INTERSPACE,
						rectIcon.bottom - 0 - m_lCharHeight,
						rectIcon.right - 0 - INTERSPACE,
						rectIcon.bottom - 0);
					pDC->DrawText(strInfo, rectInfo, DT_CENTER | DT_VCENTER | DT_SINGLELINE | DT_WORD_ELLIPSIS);
				}
			}
			if(lStyle == LVS_REPORT)
			{
			}
			// Use different color to display different image file, like ACDSee
			pCD->clrTextBk = ::ExtToColor(pThumbItem->GetFileExt(), FileColors, sizeof(FileColors) / sizeof(FileColors[0]));
			*pResult = CDRF_NEWFONT;		// don't use CDRF_SKIPDEFAULT !!
		}
		break;
	default: // Stage two handled here. (called for each item)
		*pResult = CDRF_DODEFAULT;
	}
}

void CThumbList::Clean()
{
	SaveBrowseFile();
	CleanUpThumbObjList();
	LockWindowUpdate();
	DeleteAllItems();
	UnlockWindowUpdate();

	CSingleLock SingleLock(&g_MutexThumb);
	SingleLock.Lock();
	if(m_ThumbThreadInfo.pThumbObj)
	{
		delete m_ThumbThreadInfo.pThumbObj;
	}
	m_ThumbThreadInfo.pThumbObj = NULL;
	SingleLock.Unlock();
}

BOOL CThumbList::SaveBrowseFile()
{
	if (m_bSaveThumbFile == FALSE)
		return FALSE;

	// collect thumbnail objects to thumb obj list
	ThumbObjListFromItems();

	if(IsModified())
	{
		CString strPathName;
		strPathName = m_strFolder + m_strBrowseFile;
		//make it can write
		if(_access(strPathName, 00) == 0)	//exist
		{
			DWORD dwFileAttri = 0;
			dwFileAttri = ::GetFileAttributes(strPathName);
			if(dwFileAttri & FILE_ATTRIBUTE_READONLY)
			{
				dwFileAttri &= ~FILE_ATTRIBUTE_READONLY;
				::SetFileAttributes(strPathName, dwFileAttri);
			}
		}

		CFile fileBrowse;
		BOOL bOpenSucceed = true;
		try
		{
			//first save to browser file --- name is "brwseimg.dcb"
			bOpenSucceed = fileBrowse.Open(strPathName, CFile::modeCreate | CFile::modeReadWrite);
			//create a archive and then use it to serialize data
			if(bOpenSucceed)
			{
				CArchive ar(&fileBrowse, CArchive::store);
				ar << m_strFileID;
				m_listThumbObj.Serialize(ar);
				ar.Close();
				fileBrowse.Close();
				SetModifiedFlag(false);
			}
		}
		catch (CException* e)
		{
			e->ReportError();
			throw;
		}
	}

	if(m_listThumbObj.IsEmpty())
	{
		//if no thumbnail, delete the brwseimg.tf file
		CString strPathName;
		strPathName = m_strFolder + m_strBrowseFile;

		//make it can write
		CFileStatus fs;
		if (CFile::GetStatus(strPathName, fs))
		{
			// delete .tf file just when it's size is enough small.
			int nMinLength = m_strFileID.GetLength() + sizeof(CFileStatus);
			DWORD dwLength = fs.m_size;
			if (dwLength <= (DWORD)nMinLength)
			{
				DWORD dwFileAttri = 0;
				dwFileAttri = ::GetFileAttributes(strPathName);
				if(dwFileAttri & FILE_ATTRIBUTE_READONLY)
				{
					dwFileAttri &= ~FILE_ATTRIBUTE_READONLY;
					::SetFileAttributes(strPathName, dwFileAttri);
				}
				::DeleteFile(strPathName);
			}
		}
	}

	m_listThumbObj.RemoveAll();

	return true;
}

int CThumbList::ThumbObjListFromItems()
{
	m_listThumbObj.RemoveAll();

	int nCount = GetItemCount();
	int nItem = 0;
	for (nItem = 0; nItem < nCount; nItem++)
	{
		CThumbItemInfo* pThumbItem = (CThumbItemInfo *)GetItemData(nItem);
		CThumbObj* pThumb =pThumbItem->GetThumb();
		if(pThumbItem->IsThumbReady())
		{
			m_listThumbObj.AddTail(pThumb);
		}
	}
	return m_listThumbObj.GetCount();
}

void CThumbList::CleanUpThumbObjList()
{
	POSITION pos = 0;
	CThumbObj* pThumbObj = 0;

	pos = m_listThumbObj.GetHeadPosition();
	while(pos != NULL)
	{
		pThumbObj = m_listThumbObj.GetNext(pos);
		if(pThumbObj != NULL)
		{
			delete pThumbObj;
			pThumbObj = 0;
		}
	}
	m_listThumbObj.RemoveAll();
}

void CThumbList::CleanUpItemsThumb()
{
	int nCount = GetItemCount();
	int nItem = 0;
	for (nItem = 0; nItem < nCount; nItem++)
	{
		CThumbItemInfo* pThumbItem = (CThumbItemInfo *)GetItemData(nItem);
		CThumbObj* pThumb =pThumbItem->GetThumb();
		if(pThumb != NULL)
		{
			delete pThumb;
		}
		pThumbItem->SetThumb(NULL);
	}
}

void CThumbList::OnDeleteitem(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	CThumbItemInfo* pThumbItem = reinterpret_cast<CThumbItemInfo*>(pNMListView->lParam);
	if (pThumbItem)
	{
		delete pThumbItem;
		pThumbItem = NULL;
	}
	
	*pResult = 0;
}

void CThumbList::EndThumbThread()
{
	DWORD dwExitCode;
   	if (m_pThumbThread != NULL &&
		GetExitCodeThread(m_pThumbThread->m_hThread, &dwExitCode) &&
		dwExitCode == STILL_ACTIVE)
	{
		// Kill the worker thread by setting the "kill thread" event.
		SetEvent(m_hEventWantKill);
		// thread maybe is waiting for create thumbnail
		SetEvent(m_hEventHaveWork);
		// Wait the thumb thread is dead
		WaitForSingleObject(m_hEventIsDead, INFINITE);
	}
}


void CThumbList::OnDestroy() 
{
	CListCtrl::OnDestroy();
	
	// TODO: Add your message handler code here
	m_SmallIcons.Detach();
	m_LargeIcons.Detach();
	if(m_pImageList)
	{
		delete m_pImageList;
		m_pImageList = 0;
	}
	EndThumbThread();	
	Clean();
}

void CThumbList::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	if (nSBCode == SB_THUMBTRACK)
	{
		// When drag the scroll bar, pause the thumb thread
		if (!m_bSuspendThumbThread)
		{
			m_pThumbThread->SuspendThread();
			m_bSuspendThumbThread = true;
		}
	}
	else if (nSBCode == SB_THUMBPOSITION)
	{
		if (m_bSuspendThumbThread)
		{
			m_pThumbThread->ResumeThread();
			m_bSuspendThumbThread = false;
		}
	}
	
	CListCtrl::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CThumbList::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	if (nSBCode == SB_THUMBTRACK)
	{
		if (!m_bSuspendThumbThread)
		{
			m_pThumbThread->SuspendThread();
			m_bSuspendThumbThread = true;
		}
	}
	else if (nSBCode == SB_THUMBPOSITION)
	{
		if (m_bSuspendThumbThread)
		{
			m_pThumbThread->ResumeThread();
			m_bSuspendThumbThread = false;
		}
	}
	
	CListCtrl::OnHScroll(nSBCode, nPos, pScrollBar);
}

BOOL CThumbList::GotoThumbnailView()
{
	if (m_bLVS_THUMBNAIL)
		return FALSE;
	else
	{
		m_bLVS_THUMBNAIL = true;
		m_clrNormalBk = GetBkColor();
		SetBkColor(::GetSysColor(COLOR_MENU));
		SetImageList(m_pImageList, LVSIL_NORMAL);
		Arrange(LVA_DEFAULT);
		Invalidate();
		if (m_bSuspendThumbThread)
		{
			m_pThumbThread->ResumeThread();
			m_bSuspendThumbThread = false;
		}
		// Re-start thumb create proc
		CreateThumbnails();
		return TRUE;
	}
}

BOOL CThumbList::LeaveThumbnailView()
{
	if (!m_bLVS_THUMBNAIL)
		return FALSE;
	else
	{
		m_bLVS_THUMBNAIL = false;
		SetBkColor(m_clrNormalBk);
		SetImageList(&m_LargeIcons, LVSIL_NORMAL);
		Arrange(LVA_DEFAULT);
		Invalidate();
		// If not in thumbnail view, pause the thumb thread
		if (!m_bSuspendThumbThread)
		{
			m_pThumbThread->SuspendThread();
			m_bSuspendThumbThread = true;
		}
		return TRUE;
	}
}

BOOL CThumbList::IsInThumbnailView()
{
	return m_bLVS_THUMBNAIL;
}

BOOL CThumbList::Create2(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID)
{
	// Make sure use LVS_REPORT | LVS_SHAREIMAGELISTS style.
	DWORD dwStyleNew = dwStyle | LVS_REPORT | LVS_SHAREIMAGELISTS;
	BOOL bRes = Create(dwStyleNew, rect, pParentWnd, nID);

	if (bRes)
		SetWindowLong(m_hWnd, GWL_STYLE, dwStyle);

	return bRes;
}

void CThumbList::OnChangeThumbSize(BOOL bSaveThumbFile, CSize sizeThumbSize)
{
	BOOL bCurrSaveThumbFile = IsSaveThumbFile();
	CSize sizeCurrThumbSize = ::GetThumbSize();
	CSize sizeNewThumbSize = sizeThumbSize;
	BOOL bChangeSaveThumbFile = FALSE;
	BOOL bChangeThumbSize = FALSE;

	if (bCurrSaveThumbFile != bSaveThumbFile)
	{
		SetSaveThumbFile(bSaveThumbFile);
		bChangeSaveThumbFile = TRUE;
	}
	// If save thumbnails to file, the thumbnail size must be 80x80.
	if (bSaveThumbFile)
		sizeNewThumbSize = CSize(80, 80);
	if (sizeCurrThumbSize != sizeNewThumbSize)
	{
		::SetThumbSize(sizeNewThumbSize);
		bChangeThumbSize = TRUE;
	}

	if (bChangeThumbSize)
	{
		// If change thumbnail size, need to ...
		// Re-create thumbnail view image list
		CImageList* pImageList = m_pImageList;
		CreateThumbViewImageList();
		SetImageList(m_pImageList, LVSIL_NORMAL);
		if(pImageList)
		{
			delete pImageList;
			pImageList = 0;
		}

		// Delete the old thumbnail images
		CleanUpItemsThumb();
		// Re-arrange the list items position
     	long lStyle = GetWindowLong(m_hWnd, GWL_STYLE) & LVS_TYPEMASK;
        if((lStyle == LVS_ICON) && m_bLVS_THUMBNAIL)
		{
			Arrange(LVA_DEFAULT);
			Invalidate();
		}
	}
	// Re-create the thumbnail images
	if (bChangeThumbSize || bChangeSaveThumbFile)
		CreateThumbnails();
}

int CALLBACK CThumbList::CompareFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	CThumbList* pThumbList = (CThumbList*) lParamSort;
	CThumbItemInfo* pThumbItem1 = reinterpret_cast<CThumbItemInfo*>(lParam1);
	CThumbItemInfo* pThumbItem2 = reinterpret_cast<CThumbItemInfo*>(lParam2);
	int nResult = 0;

	if (pThumbItem1 && pThumbItem2)
	{
		switch (pThumbList->m_nSortColumn) 
		{
		case 0 : // Sort on column 'Name'
			nResult = pThumbItem1->GetFileName().CompareNoCase(pThumbItem2->GetFileName());
			break;
		case 1 : // Sort on column 'Size'
			{
				ULONG FileSize1 = pThumbItem1->GetFileSizeInt();
				ULONG FileSize2 = pThumbItem2->GetFileSizeInt();
				if (FileSize1 > FileSize2)
					nResult = 1;
				else if (FileSize1 == FileSize2)
					nResult = 0;
				else
					nResult = -1;
				break;
			}
		case 2:
			nResult = pThumbItem1->GetDescription().CompareNoCase(pThumbItem2->GetDescription());
			break;
		case 3:
			{
				CTime FileDate1 = pThumbItem1->GetLastWriteTimeInt();
				CTime FileDate2 = pThumbItem2->GetLastWriteTimeInt();
				if(FileDate1 > FileDate2)
					nResult = 1;
				else if (FileDate1 == FileDate2)
					nResult = 0;
				else
					nResult = -1;
				break;
			}
		default :
			nResult = 0;
			break;
		}
	}
	return pThumbList->m_bSortAscending ? nResult : -nResult;
}


void CThumbList::OnColumnclick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	SortByColumn(pNMListView->iSubItem);
	*pResult = 0;
}

void CThumbList::SortByColumn(int nColumn)
{
	int nClickColumn = nColumn;
	int nOldSortColumn = m_nSortColumn;
	if (m_nSortColumn == nClickColumn)
		m_bSortAscending = !m_bSortAscending;
	else
		m_nSortColumn = nClickColumn;
	// Change column text
	LVCOLUMN col;
	col.mask = LVCF_TEXT;
	CString strText;
	col.pszText = strText.GetBuffer(_MAX_PATH);
	col.cchTextMax = _MAX_PATH;
	if (GetColumn(m_nSortColumn, &col))
	{
		strText.ReleaseBuffer();
		if (strText.Right(1) == _T("+") || strText.Right(1) == _T("-"))
			strText = strText.Left(strText.GetLength() - 1);
		if (m_bSortAscending)
			strText += _T("+");
		else
			strText += _T("-");
		col.pszText = strText.GetBuffer(_MAX_PATH);
		col.cchTextMax = _MAX_PATH;
		SetColumn(m_nSortColumn, &col);
	}
	if (nOldSortColumn != m_nSortColumn)
	{
		if (GetColumn(nOldSortColumn, &col))
		{
			strText.ReleaseBuffer();
			if (strText.Right(1) == _T("+") || strText.Right(1) == _T("-"))
				strText = strText.Left(strText.GetLength() - 1);
			col.pszText = strText.GetBuffer(_MAX_PATH);
			col.cchTextMax = _MAX_PATH;
			SetColumn(nOldSortColumn, &col);
		}
	}
	strText.ReleaseBuffer();

	// Sort the thumb list
	SortItems(&CompareFunc, (DWORD)this);
}

void CThumbList::Resort()
{
	SortItems(&CompareFunc, (DWORD)this);
}

BOOL CThumbList::OnItemchanged(NMHDR* pNMHDR, LRESULT* pResult, CString &strFilePath) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	BOOL bRes = FALSE;
	CThumbItemInfo* pThumbItem = reinterpret_cast<CThumbItemInfo*>(pNMListView->lParam);
	strFilePath = pThumbItem->GetFullName();
	bRes = strFilePath.IsEmpty() ? FALSE : TRUE;
	bRes &= m_bFillCompleted;

	*pResult = 0;
	return bRes;
}
