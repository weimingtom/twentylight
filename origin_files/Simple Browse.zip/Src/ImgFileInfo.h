#if !defined(AFX_IMGFILEINFO_H__52717BF6_34CF_11D3_A640_0000E8778115__INCLUDED_)
#define AFX_IMGFILEINFO_H__52717BF6_34CF_11D3_A640_0000E8778115__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ImgFileInfo.h : header file
//

#include "SHFileInfo.h"

/////////////////////////////////////////////////////////////////////////////
// CImgFileInfo command target

class CImgFileInfo : public CSHFileInfo
{
// Attributes
public:
	CImgFileInfo(LPCTSTR lpszFileName = NULL);
	virtual ~CImgFileInfo();

// Operations
public:
	static BOOL	IsImageFile(CString strFileName, CString strFilter);
	BOOL IsImageFile(CString strFilter);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CImgFileInfo)
	//}}AFX_VIRTUAL

// Implementation
protected:
};
//list type
typedef CTypedPtrList<CObList, CImgFileInfo*> CImgFileList;

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMGFILEINFO_H__52717BF6_34CF_11D3_A640_0000E8778115__INCLUDED_)
