// ImageDBView.cpp : implementation of the CListContainerWnd class
//

#include "stdafx.h"
#include "SimpleBrowse.h"

#include "MainFrm.h"
#include "SimpleBrowseDoc.h"
#include "ImgContainerWnd.h"
#include "ListContainerWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define IDC_SHELL_LIST   1
/////////////////////////////////////////////////////////////////////////////
// CListContainerWnd

IMPLEMENT_DYNCREATE(CListContainerWnd, CView)

BEGIN_MESSAGE_MAP(CListContainerWnd, CView)
	//{{AFX_MSG_MAP(CListContainerWnd)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_SHELL_LIST, OnItemchanged)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CListContainerWnd construction/destruction

CListContainerWnd::CListContainerWnd()
{
	// TODO: add construction code here

}

CListContainerWnd::~CListContainerWnd()
{
}

BOOL CListContainerWnd::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CListContainerWnd drawing

void CListContainerWnd::OnDraw(CDC* pDC)
{
	CSimpleBrowseDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

void CListContainerWnd::OnInitialUpdate()
{
	CView::OnInitialUpdate();


	// TODO: You may populate your ListView with items by directly accessing
	//  its list control through a call to GetListCtrl().

}

/////////////////////////////////////////////////////////////////////////////
// CListContainerWnd diagnostics

#ifdef _DEBUG
void CListContainerWnd::AssertValid() const
{
	CView::AssertValid();
}

void CListContainerWnd::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CSimpleBrowseDoc* CListContainerWnd::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSimpleBrowseDoc)));
	return (CSimpleBrowseDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CListContainerWnd message handlers

void CListContainerWnd::OnStyleChanged(int nStyleType, LPSTYLESTRUCT lpStyleStruct)
{
	//TODO: add code to react to the user changing the view style of your window
}

int CListContainerWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	
	// Create thumb list control
	// must use LVS_REPORT style to create column header correctly
	if (!m_ListCtrl.Create(
		WS_VISIBLE | LVS_REPORT | LVS_SHAREIMAGELISTS,
		CRect(0,0,0,0), this, IDC_SHELL_LIST))
	{
		TRACE0("Unable to create list view control.\n");
		return -1;
	}
	// to entry "thumbnail view", must:
	// 1.set LVS_ICON style
	// 2.call CThumbListCtrl::GotoThumbnailView()
	m_ListCtrl.GotoThumbnailView();
	DWORD dwStyle = LVS_ICON;
	m_ListCtrl.ModifyStyle(LVS_TYPEMASK, dwStyle);

	return 0;
}

void CListContainerWnd::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	if (m_ListCtrl.GetSafeHwnd())
		m_ListCtrl.MoveWindow(0,0,cx,cy);
	
}

void CListContainerWnd::FormatList(CString csPath)
{
	m_strCurDirectory = csPath;

	if (m_strCurDirectory.GetAt(m_strCurDirectory.GetLength()-1) != '\\')
		m_strCurDirectory += '\\';

	// the parameter pass to CThumbListCtrl::BrowseFolder() must be like "c:\folder\" instead of "c:\folder"
	m_ListCtrl.BrowseFolder(m_strCurDirectory);
}

void CListContainerWnd::OnItemchanged(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	CMainFrame *pFrame = (CMainFrame*)AfxGetApp()->m_pMainWnd;
	if (!pFrame)
		return;

	CImgContainerWnd *pView = (CImgContainerWnd*)pFrame->GetMiddlePane();

	CString szPath;
	if(m_ListCtrl.OnItemchanged(pNMHDR, pResult, szPath))
	{
		pView->m_ImageWnd.SeeFile(szPath);
	}
	
	*pResult = 0;
}
