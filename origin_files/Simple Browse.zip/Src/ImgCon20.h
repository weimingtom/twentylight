// ImgCon20.h : header file
//
/** 
@Creator: Hejinjun		Date: 03/09/98
*/
/*
Format	,	Read,	Write,     description
	"AWD",	True,	True,	"Microsoft At Woprk Document",
	"BMP",	True,	True,	"Microsoft Windows bitmap image",
	"DIB",	True,	True,	"Microsoft Windows bitmap image",
	"EPS",	FALSE,	FALSE,
	"GIF",	True,	True,	"CompuServe graphics interchange format",
	"IMG",	True,	False,
    "JPEG", True,	True,	"Joint Photographic Experts Group JFIF format" ,
	"MAC",	true,	False,
    "MNG",  True,	True,   "Multiple-image Network Graphics",
    "PCD",	True,	False,	"Photo CD" ,
    "PCX",  True,	True,   "ZSoft IBM PC Paintbrush" ,
    "PNG",	True,	True,	"Portable Network Graphics",
	"PNM",  True,	True,	"Portable anymap" ,
	"PPM",  True,	True,	"Portable pixmap format (color)" ,
	"PSD",  True,	True,	"Adobe Photoshop bitmap" ,
    "SGI",  True,	True,	"Irix RGB image" ,
    "TGA",  True,	True,	"Truevision Targa image" ,
    "TIFF",	True,	True,    "Tagged Image File Format" ,
*/
  
#ifndef _IMGCON20_
#define _IMGCON20_

typedef struct _ImageFileInfo
{
	char  strFormat[8];
	BITMAPINFOHEADER bmiHeader;
	DWORD dwColorSpace;
	WORD  wCompressMode;//No,CCITT,JPEG,LZW,Packbits,RLE
	WORD  wComQulity;//1- 100.
	WORD  wProgressive; //1 or 0.
	WORD  wVersion;
	WORD  nInterLace;
}ImageFileInfo;
/** *******************************************************************
** @Description: 
**	%This% public function is used to free memory in dll . 
** @Parameter:
**		hPixelData  -- the pointer of memory to be free.
******************************************************************* */
extern "C" void FAR PASCAL EXPORT FreeImgMemory(HGLOBAL& hPixelData);

/** *******************************************************************
** @Description: 
**	%This% public function is used to read image file int memory 
** @Parameter:
**		lpBmpInfo  -- the pointer of image infomation.
**		hPixelData	-- the handle of image rast data.
**		lpFileName	-- the file name of the image file
******************************************************************* */
extern "C" long FAR PASCAL EXPORT ReadFileToMem(BITMAPINFO* lpBmpInfo, HGLOBAL& hPixelData, LPCTSTR lpFileName);

/** *******************************************************************
** @Description: 
**	%This% public function is used to write image into file  
** @Parameter:
**		lpFileName	-- the file name of the image file
**		lpBmpInfo	-- the pointer of image infomation.
**		hPixelData	-- the handle of image rast data.
**		lpszFormt	-- the write format of image.
**		pImgInfo	-- the other info to be write (such as colors and compress)
********************************************************************/
extern "C" long FAR PASCAL EXPORT WriteMemToFile(LPCTSTR lpFileName,BITMAPINFO* lpBmpInfo, HGLOBAL hPixelData,
												 LPCTSTR lpszFormt,ImageFileInfo* pImgInfo = NULL);
/** *******************************************************************
** @Description: 
**	%This% public function is used to get format from image file  
** @Parameter:
**		lpFileName	-- the file name of the image file
** @Return: the format of image.
** @Note : The name use TIFF and JPEG.
********************************************************************/
extern "C" BSTR FAR PASCAL EXPORT GetImgFormat(LPCTSTR lpFileName) ;

/** *******************************************************************
** @Description: 
**	%This% public function is used to convert image file  to other
** @Parameter:
**		lpszDestFileName-- the file name of the dest image file
**		lpszSrcFileName	-- the file name of the source image file
**		lpszFormt		-- the write format of image.
**		pImgInfo		-- the other info to be write (such as colors and compress)
** @Return: long
** @Creator:   Hejinjun		Date:     11/20/98  
********************************************************************/
extern "C" long FAR PASCAL EXPORT ConvertFileToFile(LPCTSTR lpszDestFileName, LPCTSTR lpszSrcFileName,
													LPCTSTR lpszFormt,ImageFileInfo* pImgInfo = NULL) ;

/** *******************************************************************
** @Description: 
**	%This% public function is used to crop after scale image 
** @Parameter:
**		pThumbInfo  -- the pointer of image infomation.
**		hThumbData	-- the point of image rast data.
**		pLargeInfo	-- the info header of the source image file
**		lpstrSrcFileName-- the file name to be create thumbnail.
**		ThumbSize   -- the size of scale to 
**		rcCrop		-- the rectangel of crop after scale or before scale.
**		nMode		--
**			0 ,Create thumbnail,default value
**			1, crop first ,then scale.
**			2. Scale first,then crop,
**	1.	CreateThumbnail:rcCrop = CRect(-1,-1,-1,-1) and nMode = 0
**	2.  Scale 	rcCrop = CRect(-1,-1,-1,-1) and nMode = 1
**  3. Zoom a block of image :nMode = 2.��ֹ���ֲ�ƽ�����ơ�
** @Return: BOOL
** @Creator:   Hejinjun		Date:     04/05/99  
********************************************************************/
extern "C" BOOL FAR PASCAL EXPORT CreateNewThumbnail( BITMAPINFO* pThumbInfo, //1064 bytes.
														HGLOBAL& hThumbData,
														BITMAPINFO* pLargeHeader, //1064 bytes.
														LPCTSTR lpstrSrcFileName,
														CSize& ThumbSize,
														CRect  rcCrop = CRect(-1,-1,-1,-1), // default is all image.
														int nMode = 0);

/** *******************************************************************
** @Description: 
**	%This% public function is used to read the bitmapinfo header of image file  
** @Parameter:
**		pbmiHeader  -- the pointer of image bitmap infoheader.
**		lpszSrcFileName	-- the file name of the image file
** @Return: long
** @Creator:   Hejinjun		Date:     03/20/99 
******************************************************************* */
extern "C" BOOL FAR PASCAL EXPORT GetImageFileInfo(BITMAPINFOHEADER* pbmiHeader, LPCTSTR lpszSrcFileName);

/** *******************************************************************
** @Description: 
**	%This% public function is used for crop after scale image for memory image
** @Parameter:
**		pThumbInfo  -- the pointer of target image infomation.
**		hThumbData	-- the point of target image rast data.
**		pSrcInfo	-- the pointer of source image infomation
**		hSrcData	-- the point of source image rast data
**		ThumbSize   -- the size of scale to be
**		rcCrop		-- the rectangel of crop after scale or before scale.
**		nMode		--
**			0 ,Create thumbnail,default value
**			1, crop first ,then scale.
**			2. Scale first,then crop,
** @Return: BOOL
** @Creator:   Hejinjun		Date:     04/05/99  
********************************************************************/
extern "C" BOOL FAR PASCAL EXPORT MemScaleCrop( BITMAPINFO* pThumbInfo,HGLOBAL& hThumbData,
												BITMAPINFO* pSrcInfo,  HGLOBAL  hSrcData,
												CSize& ThumbSize,
												CRect rcCrop = CRect(-1,-1,-1,-1),
												int nMode = 0) ;

//Convert non 24 bpp to 24 bpp
extern "C" BOOL FAR PASCAL EXPORT ConvertTo24Bit(BITMAPINFO* pbmpInfo,HGLOBAL& hBits);

//if the awd file have mult page ,read it into multiple bmp file
//such as tt.bmp -->tt~tmp0.bmp,tt~tmp1.bmp
extern "C" int FAR PASCAL EXPORT AwdToMultBmp(LPCTSTR lpszAwdName, LPCTSTR lszBmpName);
#endif
