#if !defined(AFX_IMAGEWND_H__1A415236_45C0_11D4_8F33_0000E8778115__INCLUDED_)
#define AFX_IMAGEWND_H__1A415236_45C0_11D4_8F33_0000E8778115__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ImageWnd.h : header file
//

#include "oxdib.h"
#include "ImgCon20.h"
/////////////////////////////////////////////////////////////////////////////
// CImageWnd window

class CImageWnd : public CWnd
{
// Construction
public:
	CImageWnd();

// Attributes
public:
	CString m_strFullName;
	//image data
	COXDIB *m_pDIB;
	CSize m_sizeImage;

	// The next image in slide show, we will load it in background thread
	CString m_strFullNameNext;
	COXDIB *m_pDIBNext;
	CSize m_sizeImageNext;

	void SeeFile(CString strFullName);
	void PaintOnDC(CDC* pDC);
	CDC m_dcMem;
	CBitmap m_bmpMem;

	void UpdateScrollInfo();

	COLORREF m_clrBkground;
	COLORREF GetBkground() { return m_clrBkground; }
	void SetBkground(COLORREF clrBkground) { m_clrBkground = clrBkground; }

	CPoint m_ptLast;

	float m_fZoom;		// zoom scale, if -1, fit.
	float GetZoom() { return m_fZoom; }
	void SetZoom(float fZoom) { m_fZoom = fZoom; }

	void OnChangeProperties(float fZoom, COLORREF clrBkground);
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CImageWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CImageWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CImageWnd)
	afx_msg void OnPaint();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnDestroy();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMAGEWND_H__1A415236_45C0_11D4_8F33_0000E8778115__INCLUDED_)
