// ImageWnd.cpp : implementation file
//

#include "stdafx.h"
#include "SimpleBrowse.h"
#include "ImageWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CImageWnd

CImageWnd::CImageWnd()
{
	m_pDIB = new COXDIB();
	m_sizeImage = CSize(0, 0);
	m_pDIBNext = new COXDIB();
	m_sizeImageNext = CSize(0, 0);
	m_clrBkground = 0x00000000;
	m_fZoom = -1.0;
}

CImageWnd::~CImageWnd()
{
	if (m_pDIB)
	{
		delete m_pDIB;
		m_pDIB = 0;
	}
	if (m_pDIBNext)
	{
		delete m_pDIBNext;
		m_pDIBNext = 0;
	}
}


BEGIN_MESSAGE_MAP(CImageWnd, CWnd)
	//{{AFX_MSG_MAP(CImageWnd)
	ON_WM_PAINT()
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_VSCROLL()
	ON_WM_HSCROLL()
	ON_WM_DESTROY()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_KEYDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CImageWnd message handlers

void CImageWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CRect rectClient;
	GetClientRect(rectClient);
	
	// TODO: Add your message handler code here
	if (0)
	{
		PaintOnDC(&dc);
	}
	else	// Use memory DC
	{
		if (m_dcMem.GetSafeHdc() && m_bmpMem.GetSafeHandle())
		{
			CBitmap *pOldMemBitmap = m_dcMem.SelectObject(&m_bmpMem);
			PaintOnDC(&m_dcMem);
			dc.BitBlt(rectClient.left,rectClient.top, rectClient.Width(),rectClient.Height(),
							&m_dcMem, 0,0,SRCCOPY ); 
			m_dcMem.SelectObject(pOldMemBitmap);
		}
	}
	// Do not call CWnd::OnPaint() for painting messages
}

void CImageWnd::PaintOnDC(CDC* pDC)
{
	SCROLLINFO siVert, siHorz;
	GetScrollInfo(SB_VERT, &siVert);
	GetScrollInfo(SB_HORZ, &siHorz);
	CRect rectClient;
	GetClientRect(rectClient);

	pDC->FillSolidRect(rectClient, m_clrBkground);
	if (!m_pDIB->IsEmpty())
	{
		CRect rectBmp = CRect(CPoint(0, 0), m_pDIB->GetSize());
		CRect rectActualPos = rectBmp;
		if (m_fZoom == -1.0)		// Fit
		{
			if (rectActualPos.Width() > rectClient.Width() || rectActualPos.Height() > rectClient.Height())
				::RectFitToRect(rectClient, rectBmp, rectActualPos);
		}
		else
		{
			float f;
			f = (float)rectActualPos.bottom * m_fZoom;
			rectActualPos.bottom = (int)f;
			f = (float)rectActualPos.right * m_fZoom;
			rectActualPos.right = (int)f;
		}
		CSize sizeDelta;
		if (rectActualPos.Width() <= rectClient.Width())
		{
			// Display the image in the center of client area
			sizeDelta.cx = rectClient.CenterPoint().x - rectActualPos.CenterPoint().x;
		}
		else
		{
			sizeDelta.cx = -siHorz.nPos;
		}
		if (rectActualPos.Height() <= rectClient.Height())
		{
			// Display the image in the center of client area
			sizeDelta.cy = rectClient.CenterPoint().y - rectActualPos.CenterPoint().y;
		}
		else
		{
			sizeDelta.cy = -siVert.nPos;
		}
		rectActualPos.OffsetRect(sizeDelta);

		m_pDIB->Paint(pDC, rectActualPos, rectBmp);
	}
}

void CImageWnd::SeeFile(CString strFullName)
{
	if (strFullName.CompareNoCase(m_strFullName) == 0)
		return;

	BOOL bOk = true;

	m_pDIB->Empty();
	m_sizeImage = CSize(0, 0);
	m_strFullName = strFullName;

	BITMAPINFO* pInfo =(BITMAPINFO*) new BYTE[1064];
	HGLOBAL hBits;
	if (::ReadFileToMem(pInfo, hBits, m_strFullName) > 0)
	{
		bOk = m_pDIB->CreateFromHdrAndBits(pInfo, hBits);
		if (bOk)
		{
			m_sizeImage = m_pDIB->GetSize();
		}
		::FreeImgMemory(hBits);
	}
	delete [] pInfo;

	UpdateScrollInfo();
	Invalidate(FALSE);
}

int CImageWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	
	return 0;
}

void CImageWnd::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	if (cx > 0 && cy > 0)
	{
		UpdateScrollInfo();

		// Re-create memory dc and memory bitmap
		CRect rectClient;
		GetClientRect(rectClient);
		if (m_dcMem.GetSafeHdc())
			m_dcMem.DeleteDC();
		if (m_bmpMem.GetSafeHandle())
			m_bmpMem.DeleteObject();
		if (m_dcMem.GetSafeHdc() == NULL)
		{
			CClientDC dc(this);
			if (m_dcMem.CreateCompatibleDC(&dc))
			{
				if (m_bmpMem.GetSafeHandle() == NULL)
					m_bmpMem.CreateCompatibleBitmap(&dc, rectClient.Width(), rectClient.Height());
			}
		}
	}
}

void CImageWnd::UpdateScrollInfo()
{
	CRect rectClient;
	SCROLLINFO siVert, siHorz;
	CSize sizeActualImage = m_sizeImage;
	if (m_fZoom == -1.0)	// Fit
	{
		ShowScrollBar(SB_BOTH, FALSE);
		GetClientRect(rectClient);
		sizeActualImage = rectClient.Size();
	}
	else
	{
		float f;
		f = (float)sizeActualImage.cx * m_fZoom;
		sizeActualImage.cx = (int)f;
		f = (float)sizeActualImage.cy * m_fZoom;
		sizeActualImage.cy = (int)f;
	}

	GetScrollInfo(SB_VERT, &siVert);
	GetClientRect(rectClient);
	siVert.nPage = 20;
	siVert.nMin = 0;
	// If nMax - nMin <= nPage, the scroll bar did not show.
	siVert.nMax = max(0, (sizeActualImage.cy + siVert.nPage - rectClient.Height()));
	siVert.nPos = min(siVert.nMax - (int)siVert.nPage, siVert.nPos);
	SetScrollInfo(SB_VERT, &siVert);
	
	GetScrollInfo(SB_HORZ, &siHorz);
	// Important: after the last call to SetScrollInfo(), the client rect is changed, so must
	// call GetClientRect() again!
	GetClientRect(rectClient);
	siHorz.nPage = 20;
	siHorz.nMin = 0;
	siHorz.nMax = max(0, (sizeActualImage.cx + siHorz.nPage - rectClient.Width()));
	siHorz.nPos = min(siHorz.nMax - (int)siHorz.nPage, siHorz.nPos);
	SetScrollInfo(SB_HORZ, &siHorz);
}


void CImageWnd::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	SCROLLINFO si;
	GetScrollInfo(SB_VERT, &si);
	if ((UINT)(si.nMax - si.nMin) <= si.nPage || si.nPage < 1 || si.nPage != 20)
	{
		CWnd::OnVScroll(nSBCode, nPos, pScrollBar);
		return ;
	}

	int nNewPos = 0;
	int nDelta = 0;
	switch (nSBCode)
	{
	case SB_PAGEUP:
		nNewPos = si.nPos - si.nPage;
		break;
	case SB_PAGEDOWN:
		nNewPos = si.nPos + si.nPage;
		break;
	case SB_LINEUP:
		nNewPos = si.nPos - 1;
		break;
	case SB_LINEDOWN:
		nNewPos = si.nPos + 1;
		break;
	case SB_THUMBPOSITION:
		nNewPos = nPos;
		break;
	case SB_THUMBTRACK:
		nNewPos = nPos;
		break;
	default:
		nNewPos = si.nPos;
		break;
	}
	if ((UINT)nNewPos > ((UINT)si.nMax - si.nPage) || nNewPos < si.nMin)
	{
		CWnd::OnVScroll(nSBCode, nPos, pScrollBar);
		return ;
	}

	nNewPos = max(si.nMin, nNewPos);
	nNewPos = min((UINT)si.nMax - si.nPage, (UINT)nNewPos);

	if (nNewPos != si.nPos)
	{
		nDelta = nNewPos - si.nPos;

		ScrollWindow(0, -nDelta);
		UpdateWindow();

		si.fMask = SIF_POS;
		si.nPos = nNewPos;
		SetScrollInfo(SB_VERT, &si);
		Invalidate();
	}
	
	CWnd::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CImageWnd::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	SCROLLINFO si;
	GetScrollInfo(SB_HORZ, &si);
	if ((UINT)(si.nMax - si.nMin) <= si.nPage || si.nPage < 1 || si.nPage != 20)
	{
		CWnd::OnHScroll(nSBCode, nPos, pScrollBar);
		return ;
	}

	int nNewPos = 0;
	int nDelta = 0;
	switch (nSBCode)
	{
	case SB_PAGELEFT:
		nNewPos = si.nPos - si.nPage;
		break;
	case SB_PAGERIGHT:
		nNewPos = si.nPos + si.nPage;
		break;
	case SB_LINELEFT:
		nNewPos = si.nPos - 1;
		break;
	case SB_LINERIGHT:
		nNewPos = si.nPos + 1;
		break;
	case SB_THUMBPOSITION:
		nNewPos = nPos;
		break;
	case SB_THUMBTRACK:
		nNewPos = nPos;
		break;
	default:
		nNewPos = si.nPos;
		break;
	}
	if ((UINT)nNewPos > ((UINT)si.nMax - si.nPage) || nNewPos < si.nMin)
	{
		CWnd::OnHScroll(nSBCode, nPos, pScrollBar);
		return ;
	}

	nNewPos = max(si.nMin, nNewPos);
	nNewPos = min((UINT)si.nMax - si.nPage, (UINT)nNewPos);

	if (nNewPos != si.nPos)
	{
		nDelta = nNewPos - si.nPos;

		ScrollWindow(-nDelta, 0);
		UpdateWindow();

		si.fMask = SIF_POS;
		si.nPos = nNewPos;
		SetScrollInfo(SB_HORZ, &si);
		Invalidate();
	}
	
	CWnd::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CImageWnd::OnDestroy() 
{
	CWnd::OnDestroy();
	
	// TODO: Add your message handler code here
	if (m_dcMem.GetSafeHdc())
		m_dcMem.DeleteDC();
	if (m_bmpMem.GetSafeHandle())
		m_bmpMem.DeleteObject();
}

void CImageWnd::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	SetFocus();
	m_ptLast = point;
	::SetCursor(AfxGetApp()->LoadCursor(IDC_CURSOR_HAND));
	
	CWnd::OnLButtonDown(nFlags, point);
}

void CImageWnd::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if (nFlags & MK_LBUTTON)
	{
		::SetCursor(::LoadCursor(::GetModuleHandle(NULL), MAKEINTRESOURCE(IDC_CURSOR_HAND)));
		SCROLLINFO siVert, siHorz;
		GetScrollInfo(SB_VERT, &siVert);
		GetScrollInfo(SB_HORZ, &siHorz);
		CSize sizeDelta;
		sizeDelta = point - m_ptLast;
		SendMessage(WM_VSCROLL, MAKELONG(SB_THUMBTRACK, siVert.nPos - sizeDelta.cy), NULL);
		SendMessage(WM_HSCROLL, MAKELONG(SB_THUMBTRACK, siHorz.nPos - sizeDelta.cx), NULL);
		m_ptLast = point;
	}
	
	CWnd::OnMouseMove(nFlags, point);
}

void CImageWnd::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	::SetCursor(::LoadCursor(NULL, MAKEINTRESOURCE(IDC_ARROW)));
	
	CWnd::OnLButtonUp(nFlags, point);
}

void CImageWnd::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	UINT uMsg = 0;
	UINT nSBCode;
	if (nChar == VK_PRIOR || nChar == VK_NEXT || nChar == VK_UP || nChar == VK_DOWN)
		uMsg = WM_VSCROLL;
	else if (nChar == VK_LEFT || nChar == VK_RIGHT)
		uMsg = WM_HSCROLL;
	switch (nChar)
	{
	case VK_PRIOR:
		nSBCode = SB_PAGEUP;
		break;
	case VK_NEXT:
		nSBCode = SB_PAGEDOWN;
		break;
	case VK_UP:
		nSBCode = SB_PAGEUP;
//		nSBCode = SB_LINEUP;
		break;
	case VK_DOWN:
		nSBCode = SB_PAGEDOWN;
//		nSBCode = SB_LINEDOWN;
		break;
	case VK_LEFT:
		nSBCode = SB_PAGELEFT;
//		nSBCode = SB_LINELEFT;
		break;
	case VK_RIGHT:
		nSBCode = SB_PAGERIGHT;
//		nSBCode = SB_LINERIGHT;
		break;
	}
	if (uMsg == WM_VSCROLL || uMsg == WM_HSCROLL)
		SendMessage(uMsg, nSBCode, NULL);
	
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CImageWnd::OnChangeProperties(float fZoom, COLORREF clrBkground)
{
	BOOL bChangeZoom = FALSE;
	BOOL bChangeBkground = FALSE;

	if (m_fZoom != fZoom)
	{
		m_fZoom = fZoom;
		UpdateScrollInfo();
		bChangeZoom = TRUE;
	}
	if (m_clrBkground != clrBkground)
	{
		m_clrBkground = clrBkground;
		bChangeBkground = TRUE;
	}

	if (bChangeZoom || bChangeBkground)
		Invalidate();
}
