// LeftView.cpp : implementation of the CTreeContainerWnd class
//

#include "stdafx.h"
#include "SimpleBrowse.h"

#include "MainFrm.h"
#include "SimpleBrowseDoc.h"
#include "ListContainerWnd.h"
#include "TreeContainerWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define IDC_SHELL_TREE  1
/////////////////////////////////////////////////////////////////////////////
// CTreeContainerWnd

IMPLEMENT_DYNCREATE(CTreeContainerWnd, CView)

BEGIN_MESSAGE_MAP(CTreeContainerWnd, CView)
	//{{AFX_MSG_MAP(CTreeContainerWnd)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_NOTIFY(TVN_ITEMEXPANDING, IDC_SHELL_TREE, OnItemexpanding)
	ON_NOTIFY(TVN_SELCHANGED, IDC_SHELL_TREE, OnSelchanged)
	ON_NOTIFY(NM_RCLICK, IDC_SHELL_TREE, OnRclick)
	ON_NOTIFY(TVN_DELETEITEM, IDC_SHELL_TREE, OnDeleteitem)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTreeContainerWnd construction/destruction

CTreeContainerWnd::CTreeContainerWnd()
{
	// TODO: add construction code here

}

CTreeContainerWnd::~CTreeContainerWnd()
{
}

BOOL CTreeContainerWnd::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CTreeContainerWnd drawing

void CTreeContainerWnd::OnDraw(CDC* pDC)
{
	CSimpleBrowseDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}


void CTreeContainerWnd::OnInitialUpdate()
{
	CView::OnInitialUpdate();

	// TODO: You may populate your TreeView with items by directly accessing
	//  its tree control through a call to GetTreeCtrl().
}

/////////////////////////////////////////////////////////////////////////////
// CTreeContainerWnd diagnostics

#ifdef _DEBUG
void CTreeContainerWnd::AssertValid() const
{
	CView::AssertValid();
}

void CTreeContainerWnd::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CSimpleBrowseDoc* CTreeContainerWnd::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSimpleBrowseDoc)));
	return (CSimpleBrowseDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CTreeContainerWnd message handlers

int CTreeContainerWnd::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here

	// Create the shell tree control.
	if (!m_TreeCtrl.Create(
		WS_VISIBLE|TVS_HASLINES|TVS_LINESATROOT|TVS_HASBUTTONS,
		CRect(0,0,0,0), this, IDC_SHELL_TREE))
	{
		TRACE0("Unable to create tree view control.\n");
		return -1;
	}

//	m_TreeCtrl.ModifyStyleEx(0, WS_EX_STATICEDGE);
	
	// Create and associate the tree image list.
	m_TreeCtrl.EnableImages();
	m_TreeCtrl.PopulateTree();
	
	return 0;
}

void CTreeContainerWnd::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	if (m_TreeCtrl.GetSafeHwnd())
		m_TreeCtrl.MoveWindow(0,0,cx,cy);
	
}

void CTreeContainerWnd::OnItemexpanding(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	m_TreeCtrl.OnFolderExpanding(pNMHDR,pResult);
	m_TreeCtrl.Invalidate();
	
	*pResult = 0;
}

void CTreeContainerWnd::OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

	CMainFrame *pFrame = (CMainFrame*)AfxGetApp()->m_pMainWnd;
	if (!pFrame)
		return;

	CListContainerWnd *pView = (CListContainerWnd*)pFrame->GetRightPane();

	CString szPath;
	if(m_TreeCtrl.OnFolderSelected(pNMHDR,pResult,szPath))
	{
		pView->FormatList(szPath);
	}
	else 
	{
		pView->m_ListCtrl.DeleteAllItems();
	}

	*pResult = 0;
}

void CTreeContainerWnd::OnRclick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	m_TreeCtrl.GetContextMenu(pNMHDR,pResult);
	*pResult = 0;
}

void CTreeContainerWnd::OnDeleteitem(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	m_TreeCtrl.OnDeleteShellItem(pNMHDR,pResult);
	*pResult = 0;
}
