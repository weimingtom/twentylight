// ThumbnailsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SimpleBrowse.h"
#include "ThumbnailsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CThumbnailsDlg property page

IMPLEMENT_DYNCREATE(CThumbnailsDlg, CPropertyPage)

CThumbnailsDlg::CThumbnailsDlg() : CPropertyPage(CThumbnailsDlg::IDD)
{
	//{{AFX_DATA_INIT(CThumbnailsDlg)
	m_nChangeThumbSize = 1;
	m_nThumbSize = 0;
	//}}AFX_DATA_INIT
}

CThumbnailsDlg::~CThumbnailsDlg()
{
}

void CThumbnailsDlg::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CThumbnailsDlg)
	DDX_Radio(pDX, IDC_CHANGE_THUMB_SIZE, m_nChangeThumbSize);
	DDX_Text(pDX, IDC_THUMB_SIZE, m_nThumbSize);
	DDV_MinMaxInt(pDX, m_nThumbSize, 40, 400);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CThumbnailsDlg, CPropertyPage)
	//{{AFX_MSG_MAP(CThumbnailsDlg)
	ON_BN_CLICKED(IDC_CHANGE_THUMB_SIZE, OnChangeThumbSize)
	ON_BN_CLICKED(IDC_SAVE_THUMB_FILE, OnSaveThumbFile)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CThumbnailsDlg message handlers

BOOL CThumbnailsDlg::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	CSpinButtonCtrl* pCtl = (CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_THUMB_SIZE);
	pCtl->SetRange(40, 400);

	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_THUMB_SIZE);
	if (m_nChangeThumbSize != 0)
	{
		pEdit->EnableWindow(FALSE);
	}
	else
		pEdit->EnableWindow(TRUE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CThumbnailsDlg::OnChangeThumbSize() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_THUMB_SIZE);
	if (m_nChangeThumbSize != 0)
	{
		pEdit->EnableWindow(FALSE);
	}
	else
		pEdit->EnableWindow(TRUE);
	
}

void CThumbnailsDlg::OnSaveThumbFile() 
{
	// TODO: Add your control notification handler code here
	UpdateData();
	CEdit* pEdit = (CEdit*)GetDlgItem(IDC_THUMB_SIZE);
	if (m_nChangeThumbSize != 0)
	{
		pEdit->EnableWindow(FALSE);
	}
	else
		pEdit->EnableWindow(TRUE);
	
}
