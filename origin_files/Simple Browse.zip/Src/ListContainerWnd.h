// ListContainerWnd.h : interface of the CListContainerWnd class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LISTCONTAINERWND_H__82217122_3697_11D4_8F18_0000E8778115__INCLUDED_)
#define AFX_LISTCONTAINERWND_H__82217122_3697_11D4_8F18_0000E8778115__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "ThumbList.h"

class CListContainerWnd : public CView
{
protected: // create from serialization only
	CListContainerWnd();
	DECLARE_DYNCREATE(CListContainerWnd)

// Attributes
public:
	CSimpleBrowseDoc* GetDocument();
	CThumbList m_ListCtrl;		// use thumb list control
	// how to use the CThumbList class? It is very simple:
	// 1.call CThumbList::Create() and CThumbList::GotoThumbnailView() in OnCreate()
	// 2.call CThumbList::MoveWindow() in OnSize()
	// 3.call CThumbList::BrowseFolder() in FormatList()
	// that is all!

	CString m_strCurDirectory;

// Operations
public:
	void FormatList(CString csPath);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CListContainerWnd)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CListContainerWnd();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CListContainerWnd)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnStyleChanged(int nStyleType, LPSTYLESTRUCT lpStyleStruct);
	afx_msg void OnItemchanged(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ListContainerWnd.cpp
inline CSimpleBrowseDoc* CListContainerWnd::GetDocument()
   { return (CSimpleBrowseDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LISTCONTAINERWND_H__82217122_3697_11D4_8F18_0000E8778115__INCLUDED_)
