#if !defined(AFX_IMGCONTAINERWND_H__1A415237_45C0_11D4_8F33_0000E8778115__INCLUDED_)
#define AFX_IMGCONTAINERWND_H__1A415237_45C0_11D4_8F33_0000E8778115__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ImgContainerWnd.h : header file
//
#include "ImageWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CImgContainerWnd view

class CImgContainerWnd : public CView
{
protected:
	CImgContainerWnd();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CImgContainerWnd)

// Attributes
public:
	CImageWnd m_ImageWnd;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CImgContainerWnd)
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CImgContainerWnd();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CImgContainerWnd)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IMGCONTAINERWND_H__1A415237_45C0_11D4_8F33_0000E8778115__INCLUDED_)
