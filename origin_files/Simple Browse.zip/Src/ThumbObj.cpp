// ThumbObj.cpp : implementation file
//

#include "stdafx.h"
#include "SimpleBrowse.h"
#include "ThumbObj.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CThumbObj

IMPLEMENT_SERIAL(CThumbObj, CObject, 0)

CThumbObj::CThumbObj(LPCTSTR pszUNC/* = NULL*/)
{
	TCHAR szFname[_MAX_FNAME];
	TCHAR szExt[_MAX_EXT];

	m_strFullName = pszUNC;
	if (!m_strFullName.IsEmpty())
		_splitpath(pszUNC, NULL, NULL, szFname, szExt);
	m_strFileName = szFname;
	m_strFileName += szExt;

//	m_sizeThumbSize = CSize(80, 80);
	m_sizeThumbSize = ::GetThumbSize();

	memset(&m_sOrgInfoHeader, 0, sizeof(BITMAPINFOHEADER));

	m_pDIB = new COXDIB();

	m_bHaveTryToCreateThumb = false;
}

CThumbObj::~CThumbObj()
{
	if (m_pDIB)
	{
		delete m_pDIB;
		m_pDIB = 0;
	}
}

/** *******************************************************************
** @Description: 
**	%This% public function
**  is used to read/write data from/to file.
** @Parameter:
**	ar--archive object
** @Return:	  void
** @Creator:   Michael Zhang
** @Date:     11/18/97
** @Version:  0.600
**********************************************************************/
void CThumbObj::Serialize(CArchive& ar)
{
	CObject::Serialize(ar);

	if(ar.IsStoring())
	{
		ar << m_strFileName;
		m_pDIB->Write(ar);
		//original bitmap infoheader
		ar.Write(&m_sOrgInfoHeader, sizeof(BITMAPINFOHEADER));
	}
	else
	{
		ar >> m_strFileName;
		m_pDIB->Read(ar);
		//original bitmap infoheader
		ar.Read(&m_sOrgInfoHeader, sizeof(BITMAPINFOHEADER));
	}
}

/////////////////////////////////////////////////////////////////////////////
// CThumbObj message handlers
/** *******************************************************************
** @Description: 
**	%This% public function
**  is used to create its thumbnail.
** @Parameter:
**	void
** @Return:	  success or fail
** @Creator:   Michael Zhang
** @Date:     11/18/97
** @Version:  0.600
**********************************************************************/
BOOL CThumbObj::CreateThumbnail()
{
	m_sizeThumbSize = ::GetThumbSize();
	BOOL bOk = true;
	CString strFullName = m_strFullName;
	CSize sizeActualThumbSize = m_sizeThumbSize;

	m_pDIB->CreateEmptyDIB(24, m_sizeThumbSize.cx, m_sizeThumbSize.cy);
	
	HGLOBAL hThumbData = NULL;
	LPSTR    lpThumbHeader;         // Pointer to BITMAPINFOHEADER
	LPSTR    lpThumbBits;           // Pointer to DIB bits
	lpThumbHeader = (LPSTR)m_pDIB->GetDIBPtr();
	lpThumbBits = m_pDIB->FindDIBBits(lpThumbHeader);

	BITMAPINFO* pDIBInfo = (BITMAPINFO*) new BYTE[1064];
	memset((BYTE*)pDIBInfo, 0, 1064);
	memcpy((BYTE*)pDIBInfo, (BYTE*)lpThumbHeader, sizeof(BITMAPINFOHEADER));
	
	bOk =  CreateNewThumbnail((BITMAPINFO *)pDIBInfo,	// Initial values: biWidth, biHeight 
		hThumbData,										// Thumb bits data
		(BITMAPINFO*)&m_sOrgInfoHeader,					// Receive original bmp info
		strFullName,									// Source full file
		sizeActualThumbSize);							// Init and receive thumb size

	if (bOk)
	{
		((BITMAPINFOHEADER*)lpThumbHeader)->biWidth = pDIBInfo->bmiHeader.biWidth;
		((BITMAPINFOHEADER*)lpThumbHeader)->biHeight = pDIBInfo->bmiHeader.biHeight;
		((BITMAPINFOHEADER*)lpThumbHeader)->biSizeImage = pDIBInfo->bmiHeader.biSizeImage;
		memcpy((BYTE*)lpThumbBits,
			(BYTE*)hThumbData,
			::GlobalSize(hThumbData)
			);
		FreeImgMemory(hThumbData);

	}
	delete [] pDIBInfo;
   // if create thumbnail fail, cleanup the empty(black color) DIB
   if (!bOk)
   {
	   m_pDIB->Empty();
   }

   // set the "have try" flag, so don't try again later
   SetHaveTryToCreateThumbFlag();
	return bOk;
}

void CThumbObj::PaintThumbnail(CDC * pDC, CRect rectPos)
{
	CRect rectActualThumbPos;
	CRect rectBmp = CRect(CPoint(0, 0), m_pDIB->GetSize());
	rectActualThumbPos = rectBmp;
	if (rectBmp.Width() <= rectPos.Width() && rectBmp.Height() <= rectPos.Height())
	{
/*		rectActualThumbPos.left = rectPos.CenterPoint().x - rectBmp.Width() / 2;
		rectActualThumbPos.top = rectPos.CenterPoint().y - rectBmp.Height() / 2;
		rectActualThumbPos.right = rectActualThumbPos.left + rectBmp.Width();
		rectActualThumbPos.bottom = rectActualThumbPos.top + rectBmp.Height();
*/
		rectActualThumbPos.OffsetRect(rectPos.CenterPoint() - rectActualThumbPos.CenterPoint());
	}
	else
	{
		RectFitToRect(rectPos, rectBmp, rectActualThumbPos);
	}
	//paint image
	m_pDIB->Paint(pDC, rectActualThumbPos, rectBmp);
}

float /*CThumbObj::*/RectFitToRect(CRect rectDest, CRect rectSrc, CRect & rectFit)
{
	CSize sizeDest = rectDest.Size();
	CSize sizeSrc = rectSrc.Size();

	CPoint ptCenter = rectDest.CenterPoint();
	
	float fWidthRatio = (float)sizeDest.cx / sizeSrc.cx;
	float fHeightRatio = (float)sizeDest.cy / sizeSrc.cy;
	float fMinRatio;

	if(fWidthRatio < fHeightRatio)	//fit width 
	{
		rectFit.left = rectDest.left;
		rectFit.right = rectDest.right;
		rectFit.top = ptCenter.y - (long)(sizeSrc.cy * fWidthRatio / 2);
		rectFit.bottom = ptCenter.y + (long)(sizeSrc.cy * fWidthRatio / 2);
		
		fMinRatio = fWidthRatio;
	}
	else							//fit height
	{
		rectFit.top = rectDest.top;
		rectFit.bottom = rectDest.bottom;
		rectFit.left = ptCenter.x - (long)(sizeSrc.cx * fHeightRatio / 2);
		rectFit.right = ptCenter.x + (long)(sizeSrc.cx * fHeightRatio / 2);
		
		fMinRatio = fHeightRatio;
	}

	return fMinRatio;
}

BOOL CThumbObj::HaveTryToCreateThumb()
{
	return m_bHaveTryToCreateThumb;
}

void CThumbObj::SetHaveTryToCreateThumbFlag(BOOL bFlag)
{
	m_bHaveTryToCreateThumb = bFlag;
}

/** *******************************************************************
** @Description: 
**	%This% public function
**  is used to get original image information.
** @Parameter:
**	void
** @Return:	  information buffer pointer
** @Creator:   Michael Zhang
** @Date:     11/18/97
** @Version:  0.600
**********************************************************************/
BITMAPINFOHEADER* CThumbObj::GetOrgImgInfoHeader()
{
	return &m_sOrgInfoHeader;
}

LPBYTE CThumbObj::GetDIBPtr()
{
	return m_pDIB->GetDIBPtr();
}

BITMAPINFO* CThumbObj::GetImgInfo()
{
	return (BITMAPINFO*)m_pDIB->GetDIBPtr();
}

LPVOID CThumbObj::GetImgBits()
{
	return (LPVOID)m_pDIB->FindDIBBits();
}

COXDIB* CThumbObj::GetDIBObject()
{
	return m_pDIB;
}

BOOL CThumbObj::SaveImgAsFile(LPTSTR pszPath)
{
	return m_pDIB->Write(pszPath);
}

WORD CThumbObj::GetNumBitsPerPixel()
{
	return m_pDIB->GetNumBitsPerPixel();
}

WORD CThumbObj::GetNumColors()
{
	return m_pDIB->GetNumColors();
}

CSize CThumbObj::GetImgSize()
{
	return m_pDIB->GetSize();
}

BOOL CThumbObj::IsImgEmpty()
{
	return m_pDIB->IsEmpty();
}

LPBYTE CThumbObj::ImgMakeCopy()
{
	return m_pDIB->MakeCopy();
}