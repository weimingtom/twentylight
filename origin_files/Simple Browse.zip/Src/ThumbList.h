#if !defined(AFX_THUMBLIST_H__4B88DCE3_3FFC_11D4_8F26_0000E8778115__INCLUDED_)
#define AFX_THUMBLIST_H__4B88DCE3_3FFC_11D4_8F26_0000E8778115__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ThumbList.h : header file
//
#include "ThumbItemInfo.h"

#define INTERSPACE 7 //interspace between two ThumbObj, FrameBox and 
					 //ThumbnailBox and LabelBox.

// Message post from worker thread(create thumbnail thread) to main thread
// to notify that: I create one thumbnail complete, and now I am idle.
#define WM_USER_COMPLETE_AND_IDLE  (WM_USER + 1)

/////////////////////////////////////////////////////////////////////////////
// CThumbList window

// Worker thread (create thumbnail) info structure
typedef struct _THUMBTHREADINFO
{
	// for kill thread
	HANDLE hEventWantKill;
	HANDLE hEventIsDead;
	
	// for thread work
	HANDLE hEventHaveWork;
	HANDLE hEventIsIdle;

	// for notify
	CWnd *pWndNotify;

	// current thumb item info
	int nItem;
	CString strFullName;
	CThumbObj *pThumbObj;

	// if change dir, need to read thumbnail file
	BOOL bChangeDir;
} THUMBTHREADINFO, *LPTHUMBTHREADINFO;

typedef struct _FILE_COLOR
{
	LPTSTR szFileExt;
	COLORREF clrColor;
} FILECOLOR, *PFILECOLOR;

COLORREF ExtToColor(CString strExt, FILECOLOR* pFileColorTable, int nTableLength);

class CThumbList : public CListCtrl
{
// Construction
public:
	CThumbList();
	virtual ~CThumbList();
	DECLARE_DYNCREATE(CThumbList)

// Attributes
public:
	// image format string, for example, "bmp;gif;jpg"
	CString m_strImageFormat;	
	CString GetImageFormatString();
	void SetImageFormatString(CString strImageFormat);

	// When on create, do some init work: BuildColumns(), CreateImageList, etc.
	int OnCreateList(LPCREATESTRUCT lpCreateStruct);
	
	BOOL BuildColumns();
	BOOL m_bInitColumns;

	void CreateImageLists();
	void CreateThumbViewImageList();
	// thumbnail size
	CSize m_sizeThumbSize;
	LONG m_lCharHeight;			//label text character height
	// large, small and thumbnail icons
	CImageList m_LargeIcons;
	CImageList m_SmallIcons;
	CImageList *m_pImageList;
	void GetSystemImageList(CImageList * pSmallList, CImageList * pLargeList);

	// "thumbnail view" style
	BOOL m_bLVS_THUMBNAIL;
	COLORREF m_clrNormalBk;
	BOOL GotoThumbnailView();
	BOOL LeaveThumbnailView();
	BOOL IsInThumbnailView();

// Operations
public:
	CString m_strFolder;
	void BrowseFolder(CString strFolder);

	// clean tasks include: SaveBrowseFile(), CleanUpThumbObjList(), DeleteAllItems()
	void Clean();
	BOOL SaveBrowseFile();
	int ThumbObjListFromItems();
	void CleanUpThumbObjList();
	void CleanUpItemsThumb();

	CString m_strBrowseFile;	// browse file name -- "brwseimg.tf"
	CString m_strFileID;		// browse file ID -- "Image Thumbnail File"
	CThumbObjList m_listThumbObj;	// thumbnail object list, use when read/write browse file
	// modify flag, if true, the browse file should be update
	BOOL m_bModified;
	BOOL IsModified();
	void SetModifiedFlag(BOOL bModified = TRUE);

	// init tasks include: ReadBrowseFile(), FillListCtrl(), CreateThumbnails()
	void Init();
	BOOL ReadBrowseFile();
	void FillListCtrl();
	BOOL m_bFillCompleted;

	// worker thread: to create thumbnails
	static UINT ThumbThreadProc(LPVOID pParam);
	static CMutex g_MutexThumb;
	// thread, events and thread info
	CWinThread *m_pThumbThread;
	HANDLE m_hEventWantKill;
	HANDLE m_hEventIsDead;
	HANDLE m_hEventHaveWork;
	HANDLE m_hEventIsIdle;
	THUMBTHREADINFO m_ThumbThreadInfo;

	// suspend thread when drag scroll bar or leave "thumbnail" view
	BOOL m_bSuspendThumbThread;

	// worker thread: create thumbnail
	CWinThread* BeginThumbThread();
	void CreateThumbnails();
	BOOL GetThumbCreateInfo(THUMBTHREADINFO *pThreadInfo);
	int m_nFirstVisibleItem;
	int GetFirstVisibleItem();
	void EndThumbThread();

	BOOL m_bSaveThumbFile;
	BOOL IsSaveThumbFile() { return m_bSaveThumbFile; }
	void SetSaveThumbFile(BOOL bSaveThumbFile) { m_bSaveThumbFile = bSaveThumbFile; }
	BOOL Create2(DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID);

	void OnChangeThumbSize(BOOL bSaveThumbFile, CSize sizeThumbSize);

	int m_nSortColumn;
	BOOL m_bSortAscending;
	static int CALLBACK CompareFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort);
	void SortByColumn(int nColumn);
	void Resort();

	BOOL OnItemchanged(NMHDR* pNMHDR, LRESULT* pResult, CString &strFilePath);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CThumbList)
	//}}AFX_VIRTUAL

	// Generated message map functions
protected:
	//{{AFX_MSG(CThumbList)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
    afx_msg void OnGetDispInfo(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnCustomDraw(NMHDR* pNMHDR, LRESULT* pResult) ;
	afx_msg void OnDeleteitem(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg LRESULT OnCompleteAndIdle(WPARAM wParam, LPARAM lParam);
	afx_msg void OnDestroy();
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnColumnclick(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_THUMBLIST_H__4B88DCE3_3FFC_11D4_8F26_0000E8778115__INCLUDED_)
