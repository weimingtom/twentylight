// ThumbItemInfo.cpp : implementation file
//

#include "stdafx.h"
#include "ThumbItemInfo.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CThumbItemInfo

CThumbItemInfo::CThumbItemInfo(LPCTSTR lpszFileName):CImgFileInfo(lpszFileName)
{
	m_pThumbObj = 0;
}

CThumbItemInfo::~CThumbItemInfo()
{
	if (m_pThumbObj)
	{
		delete m_pThumbObj;
		m_pThumbObj = 0;
	}
}


/////////////////////////////////////////////////////////////////////////////
// CThumbItemInfo message handlers

BOOL CThumbItemInfo::SetThumb(CThumbObj *pThumbObj)
{
	m_pThumbObj = pThumbObj;
	return true;
}

CThumbObj* CThumbItemInfo::GetThumb()
{
	return m_pThumbObj;
}

BOOL CThumbItemInfo::IsThumbReady()
{
	BOOL bReady = false;
	bReady = (m_pThumbObj == 0) ? false : true;
	if (bReady)
	{
		bReady = (m_pThumbObj->GetDIBPtr() == 0) ? false : true;
	}
	return bReady;
}

BOOL CThumbItemInfo::HaveTryToCreateThumb()
{
	BOOL bReady = false;
	bReady = (m_pThumbObj == 0) ? false : true;
	if (bReady)
	{
		bReady = m_pThumbObj->HaveTryToCreateThumb();
	}
	return bReady;

}

BOOL CThumbItemInfo::CreateThumb()
{
	if (m_pThumbObj == 0)
		m_pThumbObj = new CThumbObj(m_strFileName);

	if (m_pThumbObj)
		return m_pThumbObj->CreateThumbnail();
	else
		return false;
}

void CThumbItemInfo::PaintThumb(CDC *pDC, CRect rectPos)
{
	m_pThumbObj->PaintThumbnail(pDC, rectPos);
}
