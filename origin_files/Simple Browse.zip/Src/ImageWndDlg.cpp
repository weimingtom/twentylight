// ImageWndDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SimpleBrowse.h"
#include "ImageWndDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CImageWndDlg property page

IMPLEMENT_DYNCREATE(CImageWndDlg, CPropertyPage)

CImageWndDlg::CImageWndDlg() : CPropertyPage(CImageWndDlg::IDD)
{
	//{{AFX_DATA_INIT(CImageWndDlg)
	//}}AFX_DATA_INIT
}

CImageWndDlg::~CImageWndDlg()
{
}

void CImageWndDlg::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CImageWndDlg)
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CImageWndDlg, CPropertyPage)
	//{{AFX_MSG_MAP(CImageWndDlg)
	ON_BN_CLICKED(IDC_SELECT_BKCOLOR, OnSelectBkcolor)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CImageWndDlg message handlers

BOOL CImageWndDlg::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	CComboBox *pCombo = (CComboBox *)GetDlgItem(IDC_IMAGE_ZOOM);
	if (pCombo->GetSafeHwnd())
	{
		int nSel = 0;
		CString strZoom;
		for (nSel = 0; nSel < pCombo->GetCount(); nSel++)
		{
			pCombo->GetLBText(nSel, strZoom);
			if (strZoom.CompareNoCase(_T("Fit")) == 0)
			{
				if (m_fZoom == -1) 
					break;
			}
			else
			{
				float fZoom;
				fZoom = (float)atof(strZoom.GetBuffer(_MAX_PATH));
				strZoom.ReleaseBuffer();
				if (fZoom == m_fZoom) 
					break;
			}
		}
		if (nSel == pCombo->GetCount())
			nSel -= 1;
		pCombo->SetCurSel(nSel);
	}
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CImageWndDlg::OnOK() 
{
	// TODO: Add your specialized code here and/or call the base class
	CComboBox *pCombo = (CComboBox *)GetDlgItem(IDC_IMAGE_ZOOM);
	if (pCombo->GetSafeHwnd())
	{
		int nSel = pCombo->GetCurSel();
		CString strZoom;
		pCombo->GetLBText(nSel, strZoom);
		if (strZoom.CompareNoCase(_T("Fit")) == 0)
			m_fZoom = -1;
		else
		{
			m_fZoom = (float)atof(strZoom.GetBuffer(_MAX_PATH));
			strZoom.ReleaseBuffer();
		}
	}

	CPropertyPage::OnOK();
}

void CImageWndDlg::OnSelectBkcolor() 
{
	// TODO: Add your control notification handler code here
	CColorDialog dlg;
	dlg.m_cc.Flags |= CC_FULLOPEN | CC_RGBINIT;
	dlg.m_cc.rgbResult = m_clrBkground;
	if (dlg.DoModal() == IDOK)
	{
		m_clrBkground = dlg.GetColor();
		Invalidate();
	}
	
}

void CImageWndDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	CStatic* pStatic = (CStatic*)GetDlgItem(IDC_STATIC_BKCOLOR);
	if (pStatic->GetSafeHwnd())
	{
		CRect rect;
		pStatic->GetWindowRect(rect);
		ScreenToClient(rect);
		rect.InflateRect(8, 8);
		dc.FillSolidRect(rect, m_clrBkground);
		CString strText;
		strText.Format("0x%08X", m_clrBkground);
		pStatic->SetWindowText(strText);
	}
	
	// Do not call CPropertyPage::OnPaint() for painting messages
}
